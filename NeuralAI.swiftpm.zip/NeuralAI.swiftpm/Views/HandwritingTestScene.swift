import SwiftUI
import PencilKit

struct HandwritingTestScene: View {
    
    @State var canvas = PKCanvasView()
    @State var color: Color = .white
    @State var type: PKInkingTool.InkType = .pen
    

    @State var nextPage: Bool = false

    @State var showProgressView = false
    

    @State var backgroundOpacity = 0.0
    @State var navigationButtonOpacity = 0.0
    @State var eraseButtonOpacity = 0.0
    @State var drawingPadOpacity = 0.0
    

    
    var body: some View {
        ZStack {
            VStack {
                
                Spacer()
                
                VStack {
                    VStack(alignment: .leading, spacing: 0) {
                        
                      
                        InfoTextView(subtitle: "Handwriting Test", subtitleColor: .blue, title: "Make yourself comfortable, and start writing.", titleSize: 35, bodyIsOn: true, bodyText: "When you feel ready, write the exact word given on the left side of the screen.", bodyTextColor: .secondary, bodyTextSize: 20, bodyPaddingTop: 20, bodyWidth: 800)
                    }
                    
                    HStack {
                        
                        VStack(alignment: .leading, spacing: 0) {
                            
                      
                            VStack(alignment: .leading, spacing: 5) { 
                                Text("Write")
                                    .font(.system(size: 20, weight: .bold, design: .default))
                                    .foregroundColor(Color.white)
                                Text("“Enthusiastic”")
                                    .font(.system(size: 20, weight: .bold, design: .default))
                                    .foregroundColor(Color.white)
                            }
                       
                            Button { 
                                canvas.drawing = PKDrawing()
                            } label: {
                                HStack {
                                    Spacer()
                                    Text("Erase All")
                                        .font(.system(size: 20, weight: .bold, design: .default))
                                        .foregroundColor(.white)
                                    Spacer()
                                }
                            }
                            .frame(width: 240, height: 60, alignment: .center)
                            .background(Color.red)
                            .cornerRadius(47)
                            .padding(.bottom, 20)
                            .padding(.trailing, 30)
                            .padding(.top, 40)
                            
                            Text("Use Apple Pencil for more confident results.")
                                .font(.system(size: 10, weight: .medium, design: .default))
                                .frame(width: 240)
                                .foregroundColor(.secondary)
                        }
                        .opacity(eraseButtonOpacity)
                        .basicEaseIn(delayCount: 0.7) { 
                            eraseButtonOpacity = 1.0
                        }
                        
             
                        DrawingPad(canvas: $canvas, type: $type, color: $color)
                            .cornerRadius(40)
                            .frame(width: 500, height: 300)
                            .clipped()
                            .padding(.top, 40)
                            .padding(.leading, 30)
                            .opacity(drawingPadOpacity)
                            .basicEaseIn(delayCount: 0.8) { 
                                drawingPadOpacity = 1.0
                                
                            }
                    }
                    
                }
                .frame(width: 900, height: 600)
                .clipped()
                .background(Color(.systemGray5))
                .cornerRadius(47)
                .opacity(backgroundOpacity)
                .basicEaseIn(delayCount: 0) { 
                    backgroundOpacity = 1.0
                }
                
                Spacer()
                

                HStack(alignment: .bottom, spacing: 0) {
                    Spacer()
                    Button("Next") { 
     
                        showProgressView = true
                        
         
                        DispatchQueue.main.asyncAfter(deadline: .now() + 0.01){
                            
                           
                            let canvasImage = canvas.drawing.image(from: canvas.drawing.bounds, scale: 1)
                            
                            ImageClassificationProvider().predictionResult(image: canvasImage)
                            
                            withAnimation { 
                                nextPage = true
                            }
                        }
                    }
                    .buttonStyle(NavigationButtonStyle(color: Color(.blue)))
                }
                .padding(.leading, 20)
                .padding(.bottom, 20)
                .opacity(navigationButtonOpacity)
                .basicEaseIn(delayCount: 1) { 
                    navigationButtonOpacity = 1.0
                }
            }
            .zIndex(1.0)
            

            PAIProgressView()
                .zIndex(2.0)
                .opacity(showProgressView ? 1.0 : 0.0)
        }
        .navigationStack()
        .overlay(nextPage ? TestResultsScene() : nil)
    }
    
}
