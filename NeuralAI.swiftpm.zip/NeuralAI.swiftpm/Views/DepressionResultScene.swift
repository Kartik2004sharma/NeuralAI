import SwiftUI


struct DepressionResultScene: View {
    

    let totalScore: Int
    

    @State private var backgroundOpacity = 0.0
    @State private var titleOpacity = 0.0
    @State private var infoTextsOpacity = 0.0
    @State private var navigationButtonOpacity = 0.0
    @State private var nextPage: Bool = false
    
    private var resultText: String {
        switch totalScore {
        case 0...4: return "Minimal Depression"
        case 5...9: return "Mild Depression"
        case 10...14: return "Moderate Depression"
        case 15...19: return "Moderately Severe Depression"
        default: return "Severe Depression"
        }
    }
    
    private var resultDescription: String {
        switch totalScore {
        case 0...4: return "Your depression levels are minimal. Keep maintaining a healthy lifestyle."
        case 5...9: return "You have mild depression. Consider relaxation techniques and monitoring your symptoms."
        case 10...14: return "Moderate depression detected. It might be helpful to speak with a mental health professional."
        case 15...19: return "Moderately severe depression detected. Seeking professional guidance is strongly recommended."
        default: return "Severe depression detected. It is crucial to seek professional help."
        }
    }
    

    var body: some View {
        VStack {
            Spacer()
            
            VStack(spacing: 0) {
                VStack(spacing: 0) {
                    
               
                    Text("🧠 Depression Test Results")
                        .font(.system(size: 50, weight: .bold, design: .default))
                        .foregroundColor(.white)
                        .padding(.top, 5)
                        .opacity(titleOpacity)
                        .onAppear {
                            withAnimation(.easeIn(duration: 0.5)) {
                                titleOpacity = 1.0
                            }
                        }
                    
                   
                    VStack(spacing: 10) {
                        Text("Overall Result")
                            .font(.system(size: 30, weight: .semibold, design: .default))
                            .foregroundColor(.white)
                            .padding(.top, 5)
                        Text(resultText)
                            .font(.system(size: 40, weight: .semibold, design: .default))
                            .foregroundColor(.orange)
                            .padding(.top, 5)
                        Text(resultDescription)
                            .font(.system(size: 18, weight: .regular, design: .default))
                            .foregroundColor(.white)
                            .multilineTextAlignment(.center)
                            .padding(.horizontal, 50)
                    }
                    .padding(70)
                    .opacity(infoTextsOpacity)
                    .onAppear {
                        withAnimation(.easeIn(duration: 0.5).delay(0.2)) {
                            infoTextsOpacity = 1.0
                        }
                    }
                }
            }
            .background(RoundedRectangle(cornerRadius: 47, style: .continuous)
                            .fill(Color(.systemGray5))
                            .frame(width: 900, height: 400)
                            .clipped(), alignment: .center)
            .frame(width: 900, height: 400, alignment: .center)
            .clipped()
            .cornerRadius(47)
            .opacity(backgroundOpacity)
            .onAppear {
                withAnimation(.easeIn(duration: 0.5)) {
                    backgroundOpacity = 1.0
                }
            }
            
            Spacer()
            
          
            HStack(alignment: .bottom, spacing: 0) {
                Spacer()
                Button("Next") {
                    withAnimation {
                        nextPage = true
                    }
                }
                .buttonStyle(NavigationButtonStyle(color: Color(.systemGray5)))
            }
            .padding(.leading, 20)
            .padding(.bottom, 20)
            .opacity(navigationButtonOpacity)
            .onAppear {
                withAnimation(.easeIn(duration: 0.5).delay(1)) {
                    navigationButtonOpacity = 1.0
                }
            }
        }
        .fullScreenCover(isPresented: $nextPage) {
            SeeYouSoonScene()
        }
    }
}


struct DepressionResultScene_Previews: PreviewProvider {
    static var previews: some View {
        DepressionResultScene(totalScore: 12)
    }
}
