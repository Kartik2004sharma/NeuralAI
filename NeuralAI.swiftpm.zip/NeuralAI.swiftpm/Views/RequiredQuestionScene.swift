import SwiftUI

struct RequiredQuestionScene: View {
    
    @State var nextPage: Bool = false
    

    @State var yesButtonSelected = false
    @State var noButtonSelected = false


    @State var navigationButtonIsActive = false
    
    // MARK: Animation Properties
    @State var backgroundOpacity = 0.0
    @State var yesButtonOpacity = 0.0
    @State var noButtonOpacity = 0.0
    @State var navigationButtonOpacity = 0.0
    

    
    var body: some View {
        VStack {
            
            Spacer()
            
            VStack {
                

                InfoTextView(subtitle: "Required Question", subtitleColor: .blue, title: "Did you take any caffeine or medicine" + "\n" + "today?", titleSize: 30, bodyIsOn: false, bodyText: "", bodyTextColor: .white, bodyTextSize: 0, bodyPaddingTop: 0, bodyWidth: 0)
                .padding(.top, 40)
  
                VStack(alignment: .center, spacing: 20) {
                    
           
                    Button { 
                        OverallScoreCalculator.shared.requiredQuestionAnswer = true
                        navigationButtonIsActive = true
                        noButtonSelected = false
                        yesButtonSelected = true
                    } label : {
                        HStack {
                            Spacer()
                            Text("Yes, I did")
                                .font(.system(size: 20, weight: .bold, design: .default))
                                .foregroundColor(.white)
                            Spacer()
                        }
                    }
                    .frame(width: 600, height: 60, alignment: .center)
                    .background(Color(.systemGray2))
                    .cornerRadius(47)
                    .overlay(
                        RoundedRectangle(cornerRadius: 47)
                            .stroke(Color.white, lineWidth: yesButtonSelected ? 3 : 0)
                    )
                    .opacity(yesButtonOpacity)
                    .basicEaseIn(delayCount: 0.6, {
                        yesButtonOpacity = 1.0
                    })
                    
             
                    Button { 
                        OverallScoreCalculator.shared.requiredQuestionAnswer = false
                        navigationButtonIsActive = true
                        noButtonSelected = true
                        yesButtonSelected = false
                    } label : {
                        HStack {
                            Spacer()
                            Text("No, I didn't")
                                .font(.system(size: 20, weight: .bold, design: .default))
                                .foregroundColor(.white)
                            Spacer()
                        }
                    }
                    .frame(width: 600, height: 60, alignment: .center)
                    .background(Color.blue)
                    .cornerRadius(47)
                    .overlay(
                        RoundedRectangle(cornerRadius: 47)
                                  .stroke(Color.white, lineWidth: noButtonSelected ? 3 : 0)
                    )
                    .opacity(noButtonOpacity)
                    .basicEaseIn(delayCount: 0.8, {
                        noButtonOpacity = 1.0
                    })
                }
                .padding(.bottom, 40)
            }
            .padding(.horizontal, 40)
            .background(RoundedRectangle(cornerRadius: 47, style: .continuous)
                            .fill(Color(.systemGray5)), alignment: .center)
            .opacity(backgroundOpacity)
            .basicEaseIn(delayCount: 0, {
                backgroundOpacity = 1.0
            })
            
            Spacer()
            

            HStack(alignment: .bottom, spacing: 0) {
                Spacer()
                Button("Next") { 
                    withAnimation { 
                        nextPage = true
                    }
                }
                .buttonStyle(NavigationButtonStyle(color:(.blue)))
                .disabled(
                    navigationButtonIsActive ? false : true
                )
            }
            .padding(.leading, 20)
            .padding(.bottom, 20)
            .opacity(navigationButtonIsActive ?
                navigationButtonOpacity : 0.5)
            .basicEaseIn(delayCount: 1) {
                navigationButtonOpacity = 1.0
            }
        }
        .navigationStack() 
        .overlay(nextPage ? HandTremorTestScene() : nil)
    }
    
}
