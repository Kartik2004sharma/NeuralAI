import SwiftUI

struct PHQ9QuestionnaireScene: View {
    
    @State private var currentQuestionIndex: Int = 0
    @State private var responses: [Int] = Array(repeating: -1, count: 9)
    @State private var nextPage: Bool = false
    
    private var totalScore: Int {
        return responses.filter { $0 != -1 }.reduce(0, +)
    }
    
    let questions = [
        "Little interest or pleasure in doing things?",
        "Feeling down, depressed, or hopeless?",
        "Trouble falling or staying asleep, or sleeping too much?",
        "Feeling tired or having little energy?",
        "Poor appetite or overeating?",
        "Feeling bad about yourself—or that you are a failure?",
        "Trouble concentrating on things, such as reading or watching TV?",
        "Moving or speaking so slowly that other people noticed?",
        "Thoughts that you would be better off dead or hurting yourself?"
    ]
    
    let answerOptions = [
        "Not at all", "Several days", "More than half the days", "Nearly every day"
    ]
    
    var body: some View {
        VStack {
            Spacer()
            
            VStack {
             
                InfoTextView(
                    subtitle: "PHQ-9 Questionnaire",
                    subtitleColor: .blue,
                    title: questions[currentQuestionIndex],
                    titleSize: 30,
                    bodyIsOn: false,
                    bodyText: "",
                    bodyTextColor: .white,
                    bodyTextSize: 0,
                    bodyPaddingTop: 0,
                    bodyWidth: 0
                )
                .padding(.top, 40)
                
                VStack(alignment: .center, spacing: 20) {
                    ForEach(0..<answerOptions.count, id: \ .self) { index in
                        Button {
                            responses[currentQuestionIndex] = index
                        } label: {
                            HStack {
                                Spacer()
                                Text(answerOptions[index])
                                    .font(.system(size: 20, weight: .bold, design: .rounded))
                                    .foregroundColor(.white)
                                Spacer()
                            }
                        }
                        .frame(width: 600, height: 60, alignment: .center)
                        .background(responses[currentQuestionIndex] == index ? Color.blue : Color(.systemGray2))
                        .cornerRadius(47)
                        .overlay(
                            RoundedRectangle(cornerRadius: 47)
                                .stroke(Color.white, lineWidth: responses[currentQuestionIndex] == index ? 3 : 0)
                        )
                    }
                }
                .padding(.bottom, 40)
            }
            .padding(.horizontal, 40)
            .background(RoundedRectangle(cornerRadius: 47, style: .continuous)
                            .fill(Color(.systemGray5)))
            
            Spacer()

            HStack {
                if currentQuestionIndex > 0 {
                    Button("Previous") {
                        currentQuestionIndex -= 1
                    }
                    .buttonStyle(NavigationButtonStyle(color: .gray))
                }
                
                Spacer()
                
                Button(currentQuestionIndex == questions.count - 1 ? "Submit" : "Next") {
                    if currentQuestionIndex < questions.count - 1 {
                        currentQuestionIndex += 1
                    } else {
                        nextPage = true
                    }
                }
                .buttonStyle(NavigationButtonStyle(color: .blue))
                .disabled(responses[currentQuestionIndex] == -1)
            }
            .padding(.horizontal, 20)
            .padding(.bottom, 20)
        }
        .navigationStack()
        .fullScreenCover(isPresented: $nextPage) {
            DepressionResultScene(totalScore: totalScore)
        }
    }
}
