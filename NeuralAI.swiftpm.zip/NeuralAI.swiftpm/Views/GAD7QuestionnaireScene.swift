import SwiftUI

struct GAD7QuestionnaireScene: View {
    
    @State private var currentQuestionIndex: Int = 0
    @State private var responses: [Int] = Array(repeating: -1, count: 7)
    @State private var nextPage: Bool = false
    
    private var totalScore: Int {
        return responses.filter { $0 != -1 }.reduce(0, +)
    }
    
    let questions = [
        "Feeling nervous, anxious, or on edge?",
        "Not being able to stop or control worrying?",
        "Worrying too much about different things?",
        "Trouble relaxing?",
        "Being so restless that it is hard to sit still?",
        "Becoming easily annoyed or irritable?",
        "Feeling afraid as if something awful might happen?"
    ]
    
    let answerOptions = [
        "Not at all", "Several days", "More than half the days", "Nearly every day"
    ]
    
    var body: some View {
        VStack {
            Spacer()
            
            VStack {
                InfoTextView(
                    subtitle: "GAD-7 Questionnaire",
                    subtitleColor: .purple,
                    title: questions[currentQuestionIndex],
                    titleSize: 30,
                    bodyIsOn: false,
                    bodyText: "",
                    bodyTextColor: .white,
                    bodyTextSize: 0,
                    bodyPaddingTop: 0,
                    bodyWidth: 0
                )
                .padding(.top, 40)
                
                VStack(alignment: .center, spacing: 20) {
                    ForEach(0..<answerOptions.count, id: \ .self) { index in
                        Button {
                            responses[currentQuestionIndex] = index
                        } label: {
                            HStack {
                                Spacer()
                                Text(answerOptions[index])
                                    .font(.system(size: 20, weight: .bold, design: .rounded))
                                    .foregroundColor(.white)
                                Spacer()
                            }
                        }
                        .frame(width: 600, height: 60, alignment: .center)
                        .background(responses[currentQuestionIndex] == index ? Color.blue : Color(.systemGray2))
                        .cornerRadius(47)
                        .overlay(
                            RoundedRectangle(cornerRadius: 47)
                                .stroke(Color.white, lineWidth: responses[currentQuestionIndex] == index ? 3 : 0)
                        )
                    }
                }
                .padding(.bottom, 40)
            }
            .padding(.horizontal, 40)
            .background(RoundedRectangle(cornerRadius: 47, style: .continuous)
                            .fill(Color(.systemGray5)))
            
            Spacer()
            
           
            HStack {
                if currentQuestionIndex > 0 {
                    Button("Previous") {
                        currentQuestionIndex -= 1
                    }
                    .buttonStyle(NavigationButtonStyle(color: .gray))
                }
                
                Spacer()
                
                Button(currentQuestionIndex == questions.count - 1 ? "Submit" : "Next") {
                    if currentQuestionIndex < questions.count - 1 {
                        currentQuestionIndex += 1
                    } else {
                        nextPage = true
                    }
                }
                .buttonStyle(NavigationButtonStyle(color: .purple))
                .disabled(responses[currentQuestionIndex] == -1)
            }
            .padding(.horizontal, 20)
            .padding(.bottom, 20)
        }
        .navigationStack()
        .fullScreenCover(isPresented: $nextPage) {
            AnxietyResultScene(totalScore: totalScore)
        }
    }
}
