import SwiftUI

struct WhatIsParkinsonAIScene: View {
    
  
    @State var nextPage: Bool = false
    
   
    @State var backgroundOpacity = 0.0
    @State var navigationButtonOpacity = 0.0
    

    
    var body: some View {
        VStack {
            Spacer()
            HStack(spacing: 15) {
                
                
                InfoTextView(subtitle: "What is", subtitleColor: .blue, title: "ParkinsonAI", titleSize: 50, bodyIsOn: true, bodyText: "ParkinsonAI is a machine-learning-based app that can diagnose Parkinson’s disease in 3 different tests. The first test is the hand tremor test to detect rhythmic shaking of muscles. The second test is a speaking test to detect muscle control in the throat and chest. The last and third test is a handwriting test to detect trembling handwriting.", bodyTextColor: .white, bodyTextSize: 20, bodyPaddingTop: 30, bodyWidth: 500)
                .background(RoundedRectangle(cornerRadius: 47, style: .continuous)
                                .fill(Color(.systemGray5))
                                .frame(width: 585, height: 550)
                                .clipped(), alignment: .center)
                
                
                VStack(spacing: 58) {
                    
                   
                    CardView(cardSymbolIsOn: true, cardSymbolName: "hand.wave.fill", cardSymbolSize: 40, cardSymbolColor: .white, cardSymbolWidth: 173, cardSymbolHeight: 100, cardSubtitleIsOn: true, cardSubtitle: "Step 1", cardSubtitleSize: 10, cardSubtitleColor: .orange, cardTitle: "Hand Tremor Test", cardTitleSize: 13, cardTitleColor: .white, paddingTop: 0, animationDuration: 0.6, width: 173, height: 173, cornerRadius: 47, backgroundColor: Color(.systemGray5))
                    
               
                    CardView(cardSymbolIsOn: true, cardSymbolName: "waveform", cardSymbolSize: 40, cardSymbolColor: .white, cardSymbolWidth: 173, cardSymbolHeight: 100, cardSubtitleIsOn: true, cardSubtitle: "Step 2", cardSubtitleSize: 10, cardSubtitleColor: .orange, cardTitle: "Speaking Test", cardTitleSize: 13, cardTitleColor: .white, paddingTop: 0, animationDuration: 0.7, width: 173, height: 173, cornerRadius: 47, backgroundColor: Color(.systemGray5))
                    
            
                    CardView(cardSymbolIsOn: true, cardSymbolName: "pencil.and.outline", cardSymbolSize: 40, cardSymbolColor: .white, cardSymbolWidth: 173, cardSymbolHeight: 100, cardSubtitleIsOn: true, cardSubtitle: "Step 3", cardSubtitleSize: 10, cardSubtitleColor: .orange, cardTitle: "Handwriting Test", cardTitleSize: 13, cardTitleColor: .white, paddingTop: 0, animationDuration: 0.8, width: 173, height: 173, cornerRadius: 47, backgroundColor: Color(.systemGray5))
                }
                .padding(.leading, 42)
            }
            .background(Group {
                EmptyView()
            }, alignment: .center)
            .frame(width: 900, height: 550, alignment: .center)
            .clipped()
            .cornerRadius(47)
            .opacity(backgroundOpacity)
            .basicEaseIn(delayCount: 0) { 
                backgroundOpacity = 1.0
            }
            
            Spacer()
            
            
            HStack(alignment: .bottom, spacing: 0) {
                Spacer()
                Button("Let's Start") { 
                    withAnimation { 
                        nextPage = true
                    }
                }
                .buttonStyle(NavigationButtonStyle(color: .blue))
            }
            .padding(.leading, 20)
            .padding(.bottom, 20)
            .opacity(navigationButtonOpacity)
            .basicEaseIn(delayCount: 1) { 
                navigationButtonOpacity = 1.0
            }
            
        }
        .navigationStack()
        .overlay(nextPage ? RequiredQuestionScene() : nil)
    }
    
}
