import SwiftUI

struct RequiredQuestion: View {
    

    
    @State var nextPage: Bool = false
    @State var yesButtonSelected = false
    @State var noButtonSelected = false
    @State var navigationButtonIsActive = false
    

    @State var backgroundOpacity = 0.0
    @State var yesButtonOpacity = 0.0
    @State var noButtonOpacity = 0.0
    @State var navigationButtonOpacity = 0.0
    
    var body: some View {
        VStack {
            Spacer()
            
            VStack {
   
                InfoTextView(subtitle: "Required Question", subtitleColor: .purple,
                             title: "Have you experienced any memory difficulties" + "\n" + "or confusion today?",
                             titleSize: 26, bodyIsOn: false, bodyText: "", bodyTextColor: .white,
                             bodyTextSize: 0, bodyPaddingTop: 0, bodyWidth: 0)
                .padding(.top, 30)
                
                // Answer Buttons
                VStack(alignment: .center, spacing: 20) {
                    
       
                    Button {
                        OverallScoreCalculator.shared.requiredQuestionAnswer = true
                        navigationButtonIsActive = true
                        noButtonSelected = false
                        yesButtonSelected = true
                    } label: {
                        HStack {
                            Spacer()
                            Text("Yes, I did")
                                .font(.system(size: 20, weight: .bold, design: .rounded))
                                .foregroundColor(.white)
                            Spacer()
                        }
                    }
                    .frame(width: 500, height: 55, alignment: .center)
                    .background(yesButtonSelected ? Color.purple : Color.gray.opacity(0.4))
                    .cornerRadius(47)
                    .overlay(
                        RoundedRectangle(cornerRadius: 47)
                            .stroke(Color.white, lineWidth: yesButtonSelected ? 3 : 0)
                    )
                    .opacity(yesButtonOpacity)
                    .basicEaseIn(delayCount: 0.6, {
                        yesButtonOpacity = 1.0
                    })
                    
        
                    Button {
                        OverallScoreCalculator.shared.requiredQuestionAnswer = false
                        navigationButtonIsActive = true
                        noButtonSelected = true
                        yesButtonSelected = false
                    } label: {
                        HStack {
                            Spacer()
                            Text("No, I didn't")
                                .font(.system(size: 20, weight: .bold, design: .rounded))
                                .foregroundColor(.white)
                            Spacer()
                        }
                    }
                    .frame(width: 500, height: 55, alignment: .center)
                    .background(noButtonSelected ? Color.purple : Color.gray.opacity(0.4))
                    .cornerRadius(47)
                    .overlay(
                        RoundedRectangle(cornerRadius: 47)
                            .stroke(Color.white, lineWidth: noButtonSelected ? 3 : 0)
                    )
                    .opacity(noButtonOpacity)
                    .basicEaseIn(delayCount: 0.8, {
                        noButtonOpacity = 1.0
                    })
                }
                .padding(.bottom, 30)
            }
            .padding(.horizontal, 30)
            .background(RoundedRectangle(cornerRadius: 47, style: .continuous)
                            .fill(Color(.systemGray5)))
            .opacity(backgroundOpacity)
            .basicEaseIn(delayCount: 0, {
                backgroundOpacity = 1.0
            })
            
            Spacer()
            

            HStack {
                Spacer()
                Button("Next") {
                    withAnimation {
                        nextPage = true
                    }
                }
                .buttonStyle(NavigationButtonStyle(color: .purple)) 
                .disabled(!navigationButtonIsActive)
                .opacity(navigationButtonIsActive ? navigationButtonOpacity : 0.5)
                .basicEaseIn(delayCount: 1) {
                    navigationButtonOpacity = 1.0
                }
            }
            .padding(.trailing, 30)
            .padding(.bottom, 20)
        }
        .navigationStack()
        .overlay(nextPage ? HandwritingAlzheimer() : nil)
    }
}


