import SwiftUI
import AVFoundation
import Speech

struct SpeechAnalysisTest: View {
   
    @State private var audioRecorder: AVAudioRecorder?
    @State private var isRecording = false
    @State private var recordingTime: TimeInterval = 0
    @State private var timer: Timer?
    @State private var audioURL: URL?
    
    @State private var showNextTest = false
    @State private var showProgressView = false
    @State private var currentPrompt = 0
    @State private var transcribedText = ""
    @State private var analysisComplete = false
    

    @State private var backgroundOpacity = 0.0
    @State private var promptOpacity = 0.0
    @State private var controlsOpacity = 0.0
    @State private var navigationButtonOpacity = 0.0
    

    private let prompts = [
        "Please describe what you did yesterday in detail.",
        "Count backwards from 100 by sevens.",
        "Name as many animals as you can in 30 seconds."
    ]
    

    var body: some View {
        ZStack {
            Color.black.edgesIgnoringSafeArea(.all)
            
            VStack {
                Spacer()
                
                VStack(spacing: 30) {

                    VStack(spacing: 8) {
                        Text("Speech Analysis Test")
                            .font(.system(size: 18, weight: .semibold, design: .rounded))
                            .foregroundColor(.purple.opacity(0.8))
                        
                        Text("Speak clearly into your microphone")
                            .font(.system(size: 26, weight: .bold, design: .rounded))
                            .foregroundColor(.white)
                            .multilineTextAlignment(.center)
                            .padding(.horizontal, 30)
                        
                        Text("This test analyzes speech patterns and cognitive function")
                            .font(.system(size: 16, weight: .medium, design: .rounded))
                            .foregroundColor(.gray)
                            .multilineTextAlignment(.center)
                            .padding(.horizontal, 40)
                    }
                    

                    VStack(spacing: 25) {
                        Text(prompts[currentPrompt])
                            .font(.system(size: 24, weight: .bold, design: .rounded))
                            .foregroundColor(.purple)
                            .multilineTextAlignment(.center)
                            .padding(.horizontal, 40)
                        
                        // Recording Controls
                        VStack(spacing: 20) {
                            // Recording Indicator
                            Circle()
                                .fill(isRecording ? Color.red : Color.gray)
                                .frame(width: 80, height: 80)
                                .overlay(
                                    Image(systemName: isRecording ? "stop.fill" : "mic.fill")
                                        .font(.system(size: 30))
                                        .foregroundColor(.white)
                                )
                                .onTapGesture {
                                    if isRecording {
                                        stopRecording()
                                    } else {
                                        startRecording()
                                    }
                                }

                            Text(timeString(from: recordingTime))
                                .font(.system(size: 24, weight: .medium, design: .rounded))
                                .foregroundColor(.white)
                            
                            // Transcription Display
                            if !transcribedText.isEmpty {
                                Text("Transcription:")
                                    .font(.system(size: 16, weight: .medium, design: .rounded))
                                    .foregroundColor(.gray)
                                
                                ScrollView {
                                    Text(transcribedText)
                                        .font(.system(size: 16, design: .rounded))
                                        .foregroundColor(.white)
                                        .padding()
                                }
                                .frame(maxHeight: 100)
                                .background(Color.gray.opacity(0.1))
                                .cornerRadius(10)
                            }
                        }
                        .padding(.vertical, 20)
                    }
                    .opacity(promptOpacity)
                    .basicEaseIn(delayCount: 0.5) {
                        promptOpacity = 1.0
                    }
                }
                .frame(width: 900, height: 600)
                .background(Color.gray.opacity(0.1))
                .cornerRadius(40)
                .opacity(backgroundOpacity)
                .basicEaseIn(delayCount: 0) {
                    backgroundOpacity = 1.0
                }
                
                Spacer()

                HStack {
                    Spacer()
                    
                    Button(action: {
                        if currentPrompt < prompts.count - 1 {
                            currentPrompt += 1
                            transcribedText = ""
                        } else {
                            showProgressView = true
                            analyzeSpeechData()
                        }
                    }) {
                        Text(currentPrompt < prompts.count - 1 ? "Next Prompt" : "Complete Test")
                            .font(.system(size: 18, weight: .bold, design: .rounded))
                            .frame(width: 150, height: 50)
                            .background(Color.purple)
                            .foregroundColor(.white)
                            .cornerRadius(25)
                            .shadow(radius: 5)
                    }
                    .disabled(isRecording || transcribedText.isEmpty)
                    .opacity((isRecording || transcribedText.isEmpty) ? 0.5 : 1)
                }
                .padding(.horizontal, 30)
                .padding(.bottom, 30)
                .opacity(navigationButtonOpacity)
                .basicEaseIn(delayCount: 1) {
                    navigationButtonOpacity = 1.0
                }
            }
            .zIndex(1.0)
            
       
            PAIProgressView()
                .zIndex(2.0)
                .opacity(showProgressView ? 1.0 : 0.0)
        }
        .navigationStack()
        .overlay(showNextTest ? AlzheimerTestScene() : nil)
        .onAppear {
            setupAudioSession()
        }
    }

    private func setupAudioSession() {
        let audioSession = AVAudioSession.sharedInstance()
        do {
            try audioSession.setCategory(.playAndRecord, mode: .default)
            try audioSession.setActive(true)
        } catch {
            print("Audio session setup failed: \(error)")
        }
    }
    
    private func startRecording() {
        let audioFilename = getDocumentsDirectory().appendingPathComponent("speech_recording.m4a")
        let settings = [
            AVFormatIDKey: Int(kAudioFormatMPEG4AAC),
            AVSampleRateKey: 12000,
            AVNumberOfChannelsKey: 1,
            AVEncoderAudioQualityKey: AVAudioQuality.high.rawValue
        ]
        
        do {
            audioRecorder = try AVAudioRecorder(url: audioFilename, settings: settings)
            audioRecorder?.record()
            audioURL = audioFilename
            isRecording = true
            
            // Start timer
            recordingTime = 0
            timer = Timer.scheduledTimer(withTimeInterval: 0.1, repeats: true) { _ in
                recordingTime += 0.1
            }
        } catch {
            print("Recording failed: \(error)")
        }
    }
    
    private func stopRecording() {
        audioRecorder?.stop()
        isRecording = false
        timer?.invalidate()
        
        if let url = audioURL {
            transcribeAudio(url: url)
        }
    }

    private func transcribeAudio(url: URL) {
        let recognizer = SFSpeechRecognizer()
        let request = SFSpeechURLRecognitionRequest(url: url)
        
        recognizer?.recognitionTask(with: request) { result, error in
            guard let result = result else {
                print("Recognition failed: \(error?.localizedDescription ?? "Unknown error")")
                return
            }
            
            transcribedText = result.bestTranscription.formattedString
        }
    }

    private func timeString(from timeInterval: TimeInterval) -> String {
        let minutes = Int(timeInterval) / 60
        let seconds = Int(timeInterval) % 60
        let deciseconds = Int((timeInterval * 10).truncatingRemainder(dividingBy: 10))
        return String(format: "%02d:%02d.%d", minutes, seconds, deciseconds)
    }
    
    private func getDocumentsDirectory() -> URL {
        FileManager.default.urls(for: .documentDirectory, in: .userDomainMask)[0]
    }
    
    private func analyzeSpeechData() {
        // Add speech analysis logic here
        DispatchQueue.main.asyncAfter(deadline: .now() + 2.0) {
            withAnimation {
                showNextTest = true
            }
        }
    }
}

struct SpeechAnalysisTest_Previews: PreviewProvider {
    static var previews: some View {
        SpeechAnalysisTest()
    }
}

