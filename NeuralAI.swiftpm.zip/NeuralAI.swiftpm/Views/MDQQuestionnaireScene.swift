import SwiftUI

struct MDQQuestionnaireScene: View {
    
    @State private var currentQuestionIndex: Int = 0
    @State private var responses: [Int] = Array(repeating: -1, count: 13)
    @State private var nextPage: Bool = false
    
    private var totalScore: Int {
        return responses.filter { $0 != -1 }.reduce(0, +)
    }
    
    let questions = [
        "Have you ever been so irritable that you got into arguments or fights?",
        "Have you felt much more self-confident than usual?",
        "Have you needed less sleep than usual and still felt energetic?",
        "Have you been more talkative or spoken much faster than usual?",
        "Have thoughts raced through your head so fast you couldn’t slow them down?",
        "Have you been so easily distracted that you had trouble concentrating?",
        "Have you had more energy than usual?",
        "Have you been more active or done more things than usual?",
        "Have you been more interested in sex than usual?",
        "Have you spent money in ways that caused you trouble?",
        "Have any of these experiences happened together at the same time?",
        "How much of a problem did these experiences cause for you?"
    ]
    
    let answerOptions = ["Yes", "No"]
    
    var body: some View {
        VStack {
            Spacer()
            
            VStack {

                InfoTextView(
                    subtitle: "MDQ - Mood Disorder Questionnaire",
                    subtitleColor: .indigo,
                    title: questions[currentQuestionIndex],
                    titleSize: 30,
                    bodyIsOn: false,
                    bodyText: "",
                    bodyTextColor: .white,
                    bodyTextSize: 0,
                    bodyPaddingTop: 0,
                    bodyWidth: 0
                )
                .padding(.top, 40)
                
                VStack(alignment: .center, spacing: 20) {
                    ForEach(0..<answerOptions.count, id: \ .self) { index in
                        Button {
                            responses[currentQuestionIndex] = index
                        } label: {
                            HStack {
                                Spacer()
                                Text(answerOptions[index])
                                    .font(.system(size: 20, weight: .bold, design: .rounded))
                                    .foregroundColor(.white)
                                Spacer()
                            }
                        }
                        .frame(width: 600, height: 60, alignment: .center)
                        .background(responses[currentQuestionIndex] == index ? Color.blue : Color(.systemGray2))
                        .cornerRadius(47)
                        .overlay(
                            RoundedRectangle(cornerRadius: 47)
                                .stroke(Color.white, lineWidth: responses[currentQuestionIndex] == index ? 3 : 0)
                        )
                    }
                }
                .padding(.bottom, 40)
            }
            .padding(.horizontal, 40)
            .background(RoundedRectangle(cornerRadius: 47, style: .continuous)
                            .fill(Color(.systemGray5)))
            
            Spacer()
            
            HStack {
                if currentQuestionIndex > 0 {
                    Button("Previous") {
                        currentQuestionIndex -= 1
                    }
                    .buttonStyle(NavigationButtonStyle(color: .gray))
                }
                
                Spacer()
                
                Button(currentQuestionIndex == questions.count - 1 ? "Submit" : "Next") {
                    if currentQuestionIndex < questions.count - 1 {
                        currentQuestionIndex += 1
                    } else {
                        nextPage = true
                    }
                }
                .buttonStyle(NavigationButtonStyle(color: .indigo))
                .disabled(responses[currentQuestionIndex] == -1)
            }
            .padding(.horizontal, 20)
            .padding(.bottom, 20)
        }
        .navigationStack()
        .fullScreenCover(isPresented: $nextPage) {
            BipolarResultScene(totalScore: totalScore)
        }
    }
}
