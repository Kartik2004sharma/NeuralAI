import SwiftUI

struct AlzheimerTestScene: View {
    @State private var memoryRecallScore = 0
    @State private var speechAnalysisScore = 0
    @State private var handwritingScore = 0
    @State private var testCompleted = false
    @State private var showDetailedAnalysis = false
    

    @State private var backgroundOpacity = 0.0
    @State private var resultsOpacity = 0.0
    @State private var chartOpacity = 0.0
    
    private var finalScore: Int {
        let calculator = OverallScore1()
        return calculator.calculate(
            memoryScore: memoryRecallScore,
            speechScore: speechAnalysisScore,
            handwritingScore: handwritingScore
        )
    }
    
    var body: some View {
        ZStack {
            Color.black.edgesIgnoringSafeArea(.all)
            
            ScrollView {
                VStack(spacing: 30) {
             
                    VStack(spacing: 8) {
                        Text("Cognitive Assessment Results")
                            .font(.system(size: 28, weight: .bold, design: .rounded))
                            .foregroundColor(.white)
                        
                        Text("Comprehensive Analysis")
                            .font(.system(size: 18, weight: .medium, design: .rounded))
                            .foregroundColor(.purple.opacity(0.8))
                    }
                    .padding(.top, 30)
                    
                
                    VStack(spacing: 25) {
                 
                        ZStack {
                            Circle()
                                .stroke(Color.gray.opacity(0.2), lineWidth: 15)
                                .frame(width: 150, height: 150)
                            
                            Circle()
                                .trim(from: 0, to: CGFloat(finalScore) / 100)
                                .stroke(scoreColor, style: StrokeStyle(lineWidth: 15, lineCap: .round))
                                .frame(width: 150, height: 150)
                                .rotationEffect(.degrees(-90))
                            
                            VStack {
                                Text("\(finalScore)")
                                    .font(.system(size: 36, weight: .bold, design: .rounded))
                                Text("Overall Score")
                                    .font(.system(size: 14, weight: .medium, design: .rounded))
                            }
                            .foregroundColor(.white)
                        }
                        
           
                        VStack(spacing: 15) {
                            ScoreRowView(title: "Memory Recall", score: memoryRecallScore, color: .blue)
                            ScoreRowView(title: "Speech Analysis", score: speechAnalysisScore, color: .green)
                            ScoreRowView(title: "Handwriting", score: handwritingScore, color: .orange)
                        }
                        .padding()
                        .background(Color.gray.opacity(0.1))
                        .cornerRadius(15)
                    }
                    .opacity(resultsOpacity)
                    .basicEaseIn(delayCount: 0.3) {
                        resultsOpacity = 1.0
                    }
                    
                
                    VStack(spacing: 20) {
                        Text("Assessment Summary")
                            .font(.system(size: 22, weight: .bold, design: .rounded))
                            .foregroundColor(.white)
                        
                        Text(getDiagnosisMessage())
                            .font(.system(size: 18, weight: .medium, design: .rounded))
                            .foregroundColor(.white)
                            .multilineTextAlignment(.center)
                            .padding(.horizontal)
                        
                      
                        VStack(alignment: .leading, spacing: 15) {
                            Text("Recommendations:")
                                .font(.system(size: 18, weight: .bold, design: .rounded))
                                .foregroundColor(.purple)
                            
                            ForEach(getRecommendations(), id: \.self) { recommendation in
                                HStack(alignment: .top) {
                                    Circle()
                                        .fill(Color.purple.opacity(0.5))
                                        .frame(width: 8, height: 8)
                                        .padding(.top, 6)
                                    
                                    Text(recommendation)
                                        .font(.system(size: 16, design: .rounded))
                                        .foregroundColor(.white.opacity(0.9))
                                }
                            }
                        }
                        .padding()
                        .background(Color.gray.opacity(0.1))
                        .cornerRadius(15)
                    }
                    .padding(.horizontal)
                    .opacity(chartOpacity)
                    .basicEaseIn(delayCount: 0.6) {
                        chartOpacity = 1.0
                    }
                    
             
                    HStack(spacing: 20) {
                        ActionButton(title: "Save Results", icon: "square.and.arrow.down") {
                          
                        }
                        
                        ActionButton(title: "Share", icon: "square.and.arrow.up") {
                            
                        }
                    }
                    .padding(.top, 20)
                }
                .padding(.bottom, 30)
            }
            .frame(maxWidth: 900)
            .background(Color.gray.opacity(0.1))
            .cornerRadius(40)
            .padding()
            .opacity(backgroundOpacity)
            .basicEaseIn(delayCount: 0) {
                backgroundOpacity = 1.0
            }
        }
    }
    
    // MARK: Helper Properties
    private var scoreColor: Color {
        switch finalScore {
        case 80...100: return .green
        case 50..<80: return .yellow
        default: return .red
        }
    }
    
    // MARK: Helper Functions
    private func getDiagnosisMessage() -> String {
        switch finalScore {
        case 80...100:
            return "Your cognitive function appears to be within normal range. Continue maintaining your mental health through regular cognitive exercises and a healthy lifestyle."
        case 50..<80:
            return "Some mild cognitive impairment detected. While this doesn't necessarily indicate Alzheimer's, we recommend consulting with a healthcare professional for a more thorough evaluation."
        default:
            return "The test results suggest potential cognitive concerns that should be evaluated by a healthcare professional. Please schedule an appointment with a neurologist or memory specialist for a comprehensive assessment."
        }
    }
    
    private func getRecommendations() -> [String] {
        switch finalScore {
        case 80...100:
            return [
                "Continue engaging in regular mental exercises",
                "Maintain a healthy sleep schedule",
                "Stay socially active and engaged",
                "Consider annual cognitive screenings"
            ]
        case 50..<80:
            return [
                "Schedule a follow-up with a healthcare provider",
                "Increase cognitive stimulation through puzzles and games",
                "Monitor changes in memory and cognitive function",
                "Consider lifestyle modifications to support brain health",
                "Engage in regular physical exercise"
            ]
        default:
            return [
                "Seek immediate consultation with a neurologist",
                "Begin keeping a daily cognitive journal",
                "Implement memory aids and organizational tools",
                "Ensure medication compliance if prescribed",
                "Build a support network of family and caregivers"
            ]
        }
    }
}

// MARK: - Supporting Views
struct ScoreRowView: View {
    let title: String
    let score: Int
    let color: Color
    
    var body: some View {
        HStack {
            Text(title)
                .font(.system(size: 16, weight: .medium, design: .rounded))
                .foregroundColor(.white)
            
            Spacer()
            
            Text("\(score)%")
                .font(.system(size: 16, weight: .bold, design: .rounded))
                .foregroundColor(color)
        }
    }
}

struct ActionButton: View {
    let title: String
    let icon: String
    let action: () -> Void
    
    var body: some View {
        Button(action: action) {
            HStack {
                Image(systemName: icon)
                Text(title)
            }
            .font(.system(size: 16, weight: .bold, design: .rounded))
            .frame(width: 150, height: 45)
            .background(Color.purple)
            .foregroundColor(.white)
            .cornerRadius(22.5)
        }
    }
}
struct OverallScore1 {
    func calculate(memoryScore: Int, speechScore: Int, handwritingScore: Int) -> Int {
        let weightedScore = Double(memoryScore) * 0.4 +
                          Double(speechScore) * 0.3 +
                          Double(handwritingScore) * 0.3
        return Int(round(weightedScore))
    }
}
