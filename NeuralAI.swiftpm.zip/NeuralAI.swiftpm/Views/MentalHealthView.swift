import SwiftUI
import AVKit

struct MentalHealthView: View {
    

    @State private var nextPage: Bool = false
    @State private var audioPermissionAlert = true
    @State private var videoPermissionAlert = true
    @State private var navigationButtonOpacity = 0.0
    

    var body: some View {
        NavigationView {
            VStack {
                Spacer()
                
                VStack(alignment: .leading, spacing: 0) {
               
                    InfoTextView(
                        subtitle: "NeuroAI",
                        subtitleColor: Color.purple,
                        title: "Welcome",
                        titleSize: 50,
                        bodyIsOn: true,
                        bodyText: "NeuroAI provides insights into mental health disorders, explains how AI can assist in diagnosis, and includes demo mental health tests.",
                        bodyTextColor: Color.secondary,
                        bodyTextSize: 20,
                        bodyPaddingTop: 20,
                        bodyWidth: 800
                    )
                    
               
                    HStack(spacing: 25) {
                        
                       
                        NavigationLink(destination: WhatIsDepressionScene()) {
                            CardView(
                                cardSymbolIsOn: true,
                                cardSymbolName: "exclamationmark.triangle",
                                cardSymbolSize: 70,
                                cardSymbolColor: .white,
                                cardSymbolWidth: 250,
                                cardSymbolHeight: 166,
                                cardSubtitleIsOn: true,
                                cardSubtitle: "Identify",
                                cardSubtitleSize: 15,
                                cardSubtitleColor: .white,
                                cardTitle: "Depression",
                                cardTitleSize: 26,
                                cardTitleColor: .white,
                                paddingTop: 0,
                                animationDuration: 0.6,
                                width: 250,
                                height: 250,
                                cornerRadius: 40,
                                backgroundColor: .blue
                            )
                        }
                        
                       
                        NavigationLink(destination: WhatIsAnxietyScene()) {
                            CardView(
                                cardSymbolIsOn: true,
                                cardSymbolName: "waveform.path.ecg",
                                cardSymbolSize: 70,
                                cardSymbolColor: .white,
                                cardSymbolWidth: 250,
                                cardSymbolHeight: 166,
                                cardSubtitleIsOn: true,
                                cardSubtitle: "Detect",
                                cardSubtitleSize: 15,
                                cardSubtitleColor: .white,
                                cardTitle: "Anxiety Disorders",
                                cardTitleSize: 26,
                                cardTitleColor: .white,
                                paddingTop: 0,
                                animationDuration: 0.7,
                                width: 250,
                                height: 250,
                                cornerRadius: 40,
                                backgroundColor: .purple
                            )
                        }
                        
                     
                        NavigationLink(destination: WhatIsBipolarScene()) {
                            CardView(
                                cardSymbolIsOn: true,
                                cardSymbolName: "arrow.triangle.2.circlepath",
                                cardSymbolSize: 70,
                                cardSymbolColor: .white,
                                cardSymbolWidth: 250,
                                cardSymbolHeight: 166,
                                cardSubtitleIsOn: true,
                                cardSubtitle: "Monitor",
                                cardSubtitleSize: 15,
                                cardSubtitleColor: .white,
                                cardTitle: "Bipolar Disorder",
                                cardTitleSize: 26,
                                cardTitleColor: .white,
                                paddingTop: 0,
                                animationDuration: 0.8,
                                width: 250,
                                height: 250,
                                cornerRadius: 40,
                                backgroundColor: .indigo
                            )
                        }
                    }
                    .padding(.top, 60)
                }
                
                Spacer()
            }
            .navigationBarHidden(true)
            .onAppear {
                AVCaptureDevice.requestAccess(for: .audio) { isGranted in
                    if !isGranted { audioPermissionAlert = false }
                }
                
                AVCaptureDevice.requestAccess(for: .video) { isGranted in
                    if !isGranted { videoPermissionAlert = false }
                }
            }
        }
        .navigationViewStyle(StackNavigationViewStyle())
    }
}

