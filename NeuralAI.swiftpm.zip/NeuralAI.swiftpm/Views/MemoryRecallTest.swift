import SwiftUI

struct MemoryRecallTest: View {

    @State private var currentQuestion = 0
    @State private var userAnswers: [String] = ["", "", "", "", ""]
    @State private var showNextTest = false
    @State private var showProgressView = false
    
    
    @State private var backgroundOpacity = 0.0
    @State private var questionOpacity = 0.0
    @State private var navigationButtonOpacity = 0.0
    

    private let questions = [
        "What day of the week is it?",
        "What was the word you wrote in the previous test?",
        "What season are we in?",
        "What year is it?",
        "Can you name three objects you see in this room?"
    ]
    

    var body: some View {
        ZStack {
            Color.black.edgesIgnoringSafeArea(.all)
            
            VStack {
                Spacer()
                
                VStack(spacing: 30) {
                  
                    VStack(spacing: 8) {
                        Text("Memory Recall Test")
                            .font(.system(size: 18, weight: .semibold, design: .rounded))
                            .foregroundColor(.purple.opacity(0.8))
                        
                        Text("Answer the following questions")
                            .font(.system(size: 26, weight: .bold, design: .rounded))
                            .foregroundColor(.white)
                            .multilineTextAlignment(.center)
                            .padding(.horizontal, 30)
                        
                        Text("This test evaluates short-term memory and cognitive awareness")
                            .font(.system(size: 16, weight: .medium, design: .rounded))
                            .foregroundColor(.gray)
                            .multilineTextAlignment(.center)
                            .padding(.horizontal, 40)
                    }
                    
                    
                    VStack(spacing: 25) {
                        Text(questions[currentQuestion])
                            .font(.system(size: 24, weight: .bold, design: .rounded))
                            .foregroundColor(.purple)
                            .multilineTextAlignment(.center)
                            .padding(.horizontal, 20)
                        
                        // Answer Input Field
                        TextField("Your answer", text: $userAnswers[currentQuestion])
                            .textFieldStyle(RoundedBorderTextFieldStyle())
                            .font(.system(size: 18, design: .rounded))
                            .frame(width: 400)
                            .padding(.horizontal, 20)
                            .background(Color.white.opacity(0.1))
                            .cornerRadius(10)
                        
                        // Progress Indicator
                        Text("\(currentQuestion + 1) of \(questions.count)")
                            .font(.system(size: 16, weight: .medium, design: .rounded))
                            .foregroundColor(.gray)
                    }
                    .opacity(questionOpacity)
                    .onAppear {
                        withAnimation(.easeIn(duration: 0.5)) {
                            questionOpacity = 1.0
                        }
                    }
                }
                .frame(width: 900, height: 600)
                .background(Color.gray.opacity(0.1))
                .cornerRadius(40)
                .opacity(backgroundOpacity)
                .onAppear {
                    withAnimation(.easeIn(duration: 0.5)) {
                        backgroundOpacity = 1.0
                    }
                }
                
                Spacer()
                
                // Navigation Buttons
                HStack {
                    // Back Button (if not first question)
                    if currentQuestion > 0 {
                        Button(action: {
                            withAnimation {
                                currentQuestion -= 1
                            }
                        }) {
                            Text("Previous")
                                .font(.system(size: 18, weight: .bold, design: .rounded))
                                .frame(width: 150, height: 50)
                                .background(Color.gray.opacity(0.3))
                                .foregroundColor(.white)
                                .cornerRadius(25)
                                .shadow(radius: 5)
                        }
                    }
                    
                    Spacer()
                    
                    
                    Button(action: {
                        if currentQuestion < questions.count - 1 {
                            withAnimation {
                                currentQuestion += 1
                            }
                        } else {
                            showProgressView = true
                            processResults()
                        }
                    }) {
                        Text(currentQuestion < questions.count - 1 ? "Next" : "Finish")
                            .font(.system(size: 18, weight: .bold, design: .rounded))
                            .frame(width: 150, height: 50)
                            .background(Color.purple)
                            .foregroundColor(.white)
                            .cornerRadius(25)
                            .shadow(radius: 5)
                    }
                }
                .padding(.horizontal, 30)
                .padding(.bottom, 30)
                .opacity(navigationButtonOpacity)
                .onAppear {
                    withAnimation(.easeIn(duration: 1)) {
                        navigationButtonOpacity = 1.0
                    }
                }
            }
            .zIndex(1.0)
            
    
            if showProgressView {
                ProgressView()
                    .zIndex(2.0)
            }
        }
        .overlay(showNextTest ? AnyView(SpeechAnalysisTest()) : nil)
    }
    

    private func processResults() {
        DispatchQueue.main.asyncAfter(deadline: .now() + 2.0) {
            withAnimation {
                showNextTest = true
            }
        }
    }
}


struct MemoryRecallTest_Previews: PreviewProvider {
    static var previews: some View {
        MemoryRecallTest()
    }
}

