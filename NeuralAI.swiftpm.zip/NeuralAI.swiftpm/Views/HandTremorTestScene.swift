import SwiftUI

struct HandTremorTestScene: View {

    @StateObject var cameraModel = CameraViewModel()
    

    @State var nextPage: Bool = false
    
    @State var showProgressView = false
    

    @State var backgroundOpacity = 0.0
    @State var cameraSceneOpacity = 0.0
    @State var recordButtonOpacity = 0.0
    @State var retakeButtonOpacity = 0.0
    @State var navigationButtonOpacity = 0.0
    

    
    var body: some View {
        ZStack(alignment: .center) {
            VStack {
                
                Spacer()
                
                VStack {
                    
                    
                    InfoTextView(subtitle: "Hand Tremor Test", subtitleColor: .blue, title: "Make yourself comfortable, and start recording.", titleSize: 35, bodyIsOn: true, bodyText: "Place your device in a stable place. Point your hand at the camera frame and make sure your hand is fully visible on the camera, then press the record button.", bodyTextColor: .secondary, bodyTextSize: 20, bodyPaddingTop: 20, bodyWidth: 800)
                    
                   
                    HStack(spacing: 0) {
                        
                    
                        CameraView()
                            .environmentObject(cameraModel)
                            .padding(.top, 40)
                            .padding(.trailing, 30)
                            .opacity(cameraSceneOpacity)
                            .basicEaseIn(delayCount: 0.6) {
                                cameraSceneOpacity = 1.0
                            }
                        
                    
                        VStack(spacing: 10) {
                            
                        
                            Button { 
                                cameraModel.startRecording()
                            } label : {
                                HStack {
                                    Spacer()
                                    Text(cameraModel.isRecording ? "\(Int(cameraModel.recordedDuration))" : "Record")
                                        .font(.system(size: 20, weight: .bold, design: .default))
                                        .foregroundColor(.white)
                                    Spacer()
                                }
                            }
                            .frame(width: 240, height: 60, alignment: .center)
                            .background(Color.red)
                            .cornerRadius(47)
                            .padding(.leading, 30)
                            
                     
                            Text("Recording will stop automatically after 10 seconds.")
                                .font(.system(size: 10, weight: .medium, design: .default))
                                .frame(width: 240)
                                .foregroundColor(.secondary)
                        }
                        .padding(.top, 40)
                        .opacity(recordButtonOpacity)
                        .basicEaseIn(delayCount: 0.8) { 
                            recordButtonOpacity = 1.0
                        }
                    }
                }
                .frame(width: 900, height: 600)
                .clipped()
                .background(Color(.systemGray5))
                .cornerRadius(47)
                .opacity(backgroundOpacity)
                .basicEaseIn(delayCount: 0) { 
                    backgroundOpacity = 1.0
                }
                
                Spacer()
                
               
                HStack(alignment: .bottom, spacing: 0) {
                    Spacer()
                    Button("Next") {
                        
             
                        showProgressView = true
                        
                        
                        DispatchQueue.main.asyncAfter(deadline: .now() + 0.01){
                            VideoClassificationProvider().recognizeHandPose(from: cameraModel.recordedURLs.first!)
                            withAnimation { 
                                nextPage = true
                            }
                        }
                    }
                    .buttonStyle(NavigationButtonStyle(color: Color(.blue)))
                    .disabled(
                        cameraModel.isRecording || cameraModel.recordedURLs == [] ? true : false
                    )
                }
                .padding(.leading, 20)
                .padding(.bottom, 20)
                .opacity(
                    cameraModel.isRecording || cameraModel.recordedURLs == [] ? 0.5 : navigationButtonOpacity
                )
                .basicEaseIn(delayCount: 1) {
                    navigationButtonOpacity = 1.0
                }
            }
            .zIndex(1.0)
            
           
            PAIProgressView()
                    .zIndex(2.0)
            .opacity(showProgressView ? 1.0 : 0.0)
            
        }
        .navigationStack()
        .overlay(nextPage ? SpeakingTestScene(audioRecorder: AudioRecorder()) : nil)
    }
    
}
