import SwiftUI

struct TestResultsScene: View {
    

    @ObservedObject var calculator = OverallScoreCalculator.shared

    @State var nextPage: Bool = false

    @State var backgroundOpacity = 0.0
    @State var titleOpacity = 0.0
    @State var infoTextsOpacity = 0.0
    @State var navigationButtonOpacity = 0.0
    
  
    
    var body: some View {
        VStack {
            
            Spacer()
        
            VStack(spacing: 0) {
                VStack(spacing: 0) {
                    
                    // Title
                    Text("👀 Your Test Results")
                        .font(.system(size: 50, weight: .bold, design: .default))
                        .foregroundColor(Color.white)
                        .padding(.top, 5)
                        .opacity(titleOpacity)
                        .basicEaseIn(delayCount: 0) {
                            titleOpacity = 1.0
                        }
                    
               
                    VStack(spacing: 10) {
                        Text("Overall Result")
                            .font(.system(size: 30, weight: .semibold, design: .default))
                            .foregroundColor(Color.white)
                            .padding(.top, 5)
                        Text("\(calculator.calculate())% Risk of Parkinson's")
                            .font(.system(size: 30, weight: .semibold, design: .default))
                            .foregroundColor(Color.orange)
                            .padding(.top, 5)
                    }
                    .padding(70)
                    .opacity(infoTextsOpacity)
                    .basicEaseIn(delayCount: 0.2) {
                        infoTextsOpacity = 1.0
                    }
                }
                
               
                HStack(spacing: 120) {
                    
           
                    ScoreCardView(title: "Hand Tremor Test", score: calculator.handTremorTestResult)
                    
    
                    ScoreCardView(title: "Speaking Test", score: calculator.speakingTestResult)
                    
                  
                    ScoreCardView(title: "Handwriting Test", score: calculator.handwritingTestResult)
                }
                .padding(.all, 20)
            }
            .background(RoundedRectangle(cornerRadius: 47, style: .continuous)
                            .fill(Color(.systemGray5))
                            .frame(width: 900, height: 550)
                            .clipped(), alignment: .center)
            .frame(width: 900, height: 550, alignment: .center)
            .clipped()
            .cornerRadius(47)
            .opacity(backgroundOpacity)
            .basicEaseIn(delayCount: 0) {
                backgroundOpacity = 1.0
            }
            
            Spacer()
            
         
            HStack(alignment: .bottom, spacing: 0) {
                Spacer()
                ActionButton(title: "Next", icon: "arrow.right") {
                    withAnimation {
                        nextPage = true
                    }
                }
            }
            .padding(.leading, 20)
            .padding(.bottom, 20)
            .opacity(navigationButtonOpacity)
            .basicEaseIn(delayCount: 1) {
                navigationButtonOpacity = 1.0
            }
        }
        .navigationStack()
        .overlay(nextPage ? SeeYouSoonScene() : nil)
    }
}
private extension TestResultsScene {
    func getDiagnosisMessage() -> String {
        switch calculator.calculate() {
        case 80...100:
            return "Your cognitive and motor functions appear normal. Keep maintaining a healthy lifestyle."
        case 50..<80:
            return "Some mild impairment detected. Consider consulting a neurologist for further evaluation."
        default:
            return "Significant concerns detected. Immediate consultation with a specialist is recommended."
        }
    }
    
    func getRecommendations() -> [String] {
        switch calculator.calculate() {
        case 80...100:
            return [
                "Continue regular mental and physical exercises",
                "Maintain a balanced diet",
                "Ensure adequate sleep and stress management"
            ]
        case 50..<80:
            return [
                "Increase physical and cognitive exercises",
                "Consult a specialist for further evaluation",
                "Monitor symptoms regularly"
            ]
        default:
            return [
                "Seek immediate medical consultation",
                "Adopt assistive tools for daily tasks",
                "Build a strong support network"
            ]
        }
    }
}

struct ScoreCardView: View {
    let title: String
    let score: Int
    
    var body: some View {
        VStack {
            Text(title)
                .font(.system(size: 16, weight: .medium, design: .rounded))
                .foregroundColor(.white)
            
            Text("\(score)%")
                .font(.system(size: 40, weight: .bold, design: .rounded))
                .foregroundColor(Color.orange)
        }
        .frame(width: 173, height: 173)
        .background(Color(.systemGray2))
        .cornerRadius(47)
    }
}
