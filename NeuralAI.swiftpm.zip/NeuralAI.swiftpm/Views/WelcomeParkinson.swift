//
//  WelcomeParkinson.swift
//  ParkinsonAI
//
//  Created by Kartik Sharma on 08/02/25.
//
import SwiftUI
import AVKit

struct WelcomeParkinson: View {
    
    // MARK: Properties
    
    // Controlling the page navigation.
    @State var nextPage: Bool = false
    
    @State var audioPermissionAlert = true
    @State var videoPermissionAlert = true
    
    // MARK: Animation Properties
    @State var navigationButtonOpacity = 0.0
    
    // MARK: View
    
    var body: some View {
        VStack {
            
            Spacer()
            
            VStack(alignment: .leading, spacing: 0) {
                
                // The informational text which is appears on the top of the screen.
                InfoTextView(subtitle: "ParkinsonAI", subtitleColor: Color.blue, title: "Welcome", titleSize: 50, bodyIsOn: true, bodyText: "ParkinsonAI is here to give information about Parkinson’s disease, show how machine learning can diagnose Parkinson’s disease, and a demo Parkinson's test.", bodyTextColor: Color.secondary, bodyTextSize: 20, bodyPaddingTop: 20, bodyWidth: 800)
                
                // Card View
                HStack(spacing: 25) {
                    
                    // "What is Parkinson" Card
                    CardView(cardSymbolIsOn: true, cardSymbolName: "brain.head.profile", cardSymbolSize: 70, cardSymbolColor: .white, cardSymbolWidth: 250, cardSymbolHeight: 166, cardSubtitleIsOn: true, cardSubtitle: "What is", cardSubtitleSize: 15, cardSubtitleColor: .white, cardTitle: "Parkinson", cardTitleSize: 26, cardTitleColor: .white, paddingTop: 0, animationDuration: 0.6, width: 250, height: 250, cornerRadius: 40, backgroundColor: .blue)
                    
                    // "What is ParkinsonAI" Card
                    CardView(cardSymbolIsOn: true, cardSymbolName: "waveform", cardSymbolSize: 70, cardSymbolColor: .white, cardSymbolWidth: 250, cardSymbolHeight: 166, cardSubtitleIsOn: true, cardSubtitle: "What is", cardSubtitleSize: 15, cardSubtitleColor: .white, cardTitle: "ParkinsonAI", cardTitleSize: 26, cardTitleColor: .white, paddingTop: 0, animationDuration: 0.7, width: 250, height: 250, cornerRadius: 40, backgroundColor: .indigo)
                    
                    //  "AI Diagnosis" Card
                    CardView(cardSymbolIsOn: true, cardSymbolName: "stethoscope", cardSymbolSize: 70, cardSymbolColor: .white, cardSymbolWidth: 250, cardSymbolHeight: 166, cardSubtitleIsOn: false, cardSubtitle: "", cardSubtitleSize: 0, cardSubtitleColor: .white, cardTitle: "AI Diagnosis", cardTitleSize: 26, cardTitleColor: .white, paddingTop: 0, animationDuration: 0.8, width: 250, height: 250, cornerRadius: 40, backgroundColor: .purple)
                }
                .background(Group {
                    EmptyView()
                }, alignment: .center)
                .padding(.top, 60)
            }
            
            Spacer()
            
            // Navigation Button
            HStack(alignment: .bottom, spacing: 0) {
                Spacer()
                Button("Get Started") {
                    withAnimation {
                        nextPage = true
                    }
                }
                .buttonStyle(NavigationButtonStyle(color: .blue))
            }
            .padding(.leading, 20)
            .padding(.bottom, 20)
            .opacity(navigationButtonOpacity)
            .basicEaseIn(delayCount: 1, {
                navigationButtonOpacity = 1.0
            })

        }
        .navigationStack()
        .overlay(nextPage ? WhatIsParkinsonScene() : nil)
        .onAppear {
            AVCaptureDevice.requestAccess(for: .audio) { isGranted in
                if isGranted == false {
                    audioPermissionAlert = false
                }
            }
            
            AVCaptureDevice.requestAccess(for: .video) { isGranted in
                if isGranted == false {
                    videoPermissionAlert = false
                }
            }
        }
    }
    
}
