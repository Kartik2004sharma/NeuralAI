import SwiftUI


struct BipolarResultScene: View {
    
  
    let totalScore: Int
    
    @State private var nextPage: Bool = false
    @State private var backgroundOpacity = 0.0
    @State private var titleOpacity = 0.0
    @State private var infoTextsOpacity = 0.0
    @State private var navigationButtonOpacity = 0.0
    
    private var bipolarResult: String {
        totalScore >= 7 ? "High likelihood of Bipolar Disorder" : "Low likelihood of Bipolar Disorder"
    }
    
    private var bipolarDescription: String {
        totalScore >= 7 ? "Your responses suggest a high likelihood of Bipolar Disorder. Please consult a mental health professional for further evaluation."
        : "Your responses suggest a low likelihood of Bipolar Disorder. However, if you have concerns, consider speaking to a professional."
    }
    
    var body: some View {
        VStack {
            Spacer()
            
            VStack(spacing: 0) {
                VStack(spacing: 0) {
                    Text("🧠 Bipolar Test Results")
                        .font(.system(size: 50, weight: .bold))
                        .foregroundColor(.white)
                        .padding(.top, 5)
                        .opacity(titleOpacity)
                        .onAppear {
                            withAnimation(.easeIn(duration: 0.5)) {
                                titleOpacity = 1.0
                            }
                        }
                    
                    VStack(spacing: 10) {
                        Text("Bipolar Disorder Likelihood")
                            .font(.system(size: 30, weight: .semibold))
                            .foregroundColor(.white)
                            .padding(.top, 5)
                        Text(bipolarResult)
                            .font(.system(size: 30, weight: .semibold))
                            .foregroundColor(.orange)
                            .padding(.top, 5)
                        Text(bipolarDescription)
                            .font(.system(size: 18))
                            .foregroundColor(.white)
                            .multilineTextAlignment(.center)
                            .padding(.top, 10)
                            .frame(width: 500)
                    }
                    .padding(70)
                    .opacity(infoTextsOpacity)
                    .onAppear {
                        withAnimation(.easeIn(duration: 0.5).delay(0.2)) {
                            infoTextsOpacity = 1.0
                        }
                    }
                }
            }
            .background(
                RoundedRectangle(cornerRadius: 47)
                    .fill(Color(.systemGray5))
                    .frame(width: 900, height: 400)
            )
            .cornerRadius(47)
            .opacity(backgroundOpacity)
            .onAppear {
                withAnimation(.easeIn(duration: 0.5)) {
                    backgroundOpacity = 1.0
                }
            }
            
            Spacer()
            
            HStack {
                Spacer()
                Button("Next") {
                    withAnimation {
                        nextPage = true
                    }
                }
                .buttonStyle(NavigationButtonStyle(color: Color(.systemGray5)))
            }
            .padding(.horizontal, 20)
            .padding(.bottom, 20)
            .opacity(navigationButtonOpacity)
            .onAppear {
                withAnimation(.easeIn(duration: 0.5).delay(1)) {
                    navigationButtonOpacity = 1.0
                }
            }
        }
        .fullScreenCover(isPresented: $nextPage) {
            SeeYouSoonScene()
        }
    }
}


struct BipolarResultScene_Previews: PreviewProvider {
    static var previews: some View {
        BipolarResultScene(totalScore: 8)  
    }
}
