import SwiftUI

struct WhatIsAnxietyScene: View {

    @State var nextPage: Bool = false
    
 
    @State var backgroundOpacity = 0.0
    @State var navigationButtonOpacity = 0.0
    
    // MARK: View
    
    var body: some View {
        VStack {
            Spacer()
            HStack(spacing: 98) {
                
                
                InfoTextView(subtitle: "What is", subtitleColor: .purple, title: "Anxiety Disorder?", titleSize: 50, bodyIsOn: true, bodyText: "Anxiety disorders are a group of mental health disorders that cause excessive fear, worry, and distress. These include generalized anxiety disorder, panic disorder, social anxiety disorder, and other specific phobias. Anxiety can interfere with daily activities and affect one's overall well-being.", bodyTextColor: .white, bodyTextSize: 20, bodyPaddingTop: 30, bodyWidth: 500)
                .offset(x: -30, y: 0)
            
             
                VStack(alignment: .trailing) {
                    Image(systemName: "waveform.path.ecg")
                        .font(.system(size: 120, weight: .bold, design: .default))
                }
                .background(RoundedRectangle(cornerRadius: 47, style: .continuous)
                    .fill(Color.purple)
                    .frame(width: 300, height: 550, alignment: .trailing)
                    .clipped(), alignment: .center)
            }
            .background(RoundedRectangle(cornerRadius: 47, style: .continuous)
                .fill(Color(.systemGray5))
                .frame(width: 900, height: 550)
                .clipped(), alignment: .center)
            .opacity(backgroundOpacity)
            .basicEaseIn(delayCount: 0) {
                backgroundOpacity = 1.0
            }
        
            Spacer()
            
           
            HStack(alignment: .bottom, spacing: 0) {
                Spacer()
                Button("Next") {
                    withAnimation {
                        nextPage = true
                    }
                }
                .buttonStyle(NavigationButtonStyle(color: .purple))
            }
            .padding(.leading, 20)
            .padding(.bottom, 20)
            .opacity(navigationButtonOpacity)
            .basicEaseIn(delayCount: 0.6) {
                navigationButtonOpacity = 1.0
            }
        }
        .navigationStack()
        .overlay(nextPage ? WhatIsAnxietyAIScene() : nil)
    }
}

