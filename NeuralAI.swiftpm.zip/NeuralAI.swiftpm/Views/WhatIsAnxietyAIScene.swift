import SwiftUI

struct WhatIsAnxietyAIScene: View {
    
    @State var nextPage: Bool = false
    @State var backgroundOpacity = 0.0
    @State var navigationButtonOpacity = 0.0
    
    var body: some View {
        VStack {
            Spacer()
            HStack(spacing: 98) {
                
                InfoTextView(
                    subtitle: "What is",
                    subtitleColor: .purple,
                    title: "AnxietyAI",
                    titleSize: 50,
                    bodyIsOn: true,
                    bodyText: "AnxietyAI is an advanced tool designed to analyze anxiety symptoms using a self-reported anxiety questionnaire. This tool helps in assessing anxiety levels through a structured set of questions.",
                    bodyTextColor: .white,
                    bodyTextSize: 20,
                    bodyPaddingTop: 30,
                    bodyWidth: 500
                )
                .offset(x: -30, y: 0)
                
                VStack(alignment: .trailing) {
                    Image(systemName: "list.bullet.rectangle")
                        .font(.system(size: 120, weight: .bold, design: .default))
                }
                .background(RoundedRectangle(cornerRadius: 47, style: .continuous)
                    .fill(Color.purple)
                    .frame(width: 300, height: 550, alignment: .trailing)
                    .clipped(), alignment: .center)
            }
            .background(RoundedRectangle(cornerRadius: 47, style: .continuous)
                .fill(Color(.systemGray5))
                .frame(width: 900, height: 550)
                .clipped(), alignment: .center)
            .opacity(backgroundOpacity)
            .basicEaseIn(delayCount: 0) {
                backgroundOpacity = 1.0
            }
            
            Spacer()
            
            HStack(alignment: .bottom, spacing: 0) {
                Spacer()
                Button("Let's Start") {
                    withAnimation {
                        nextPage = true
                    }
                }
                .buttonStyle(NavigationButtonStyle(color: .purple))
            }
            .padding(.leading, 20)
            .padding(.bottom, 20)
            .opacity(navigationButtonOpacity)
            .basicEaseIn(delayCount: 0.6) {
                navigationButtonOpacity = 1.0
            }
        }
        .navigationStack()
        .overlay(nextPage ? GAD7QuestionnaireScene() : nil)
    }
}

