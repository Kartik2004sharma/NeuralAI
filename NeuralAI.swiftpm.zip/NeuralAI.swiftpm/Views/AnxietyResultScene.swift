import SwiftUI

struct AnxietyResultScene: View {
    
    
    let totalScore: Int
    
  
    @State private var backgroundOpacity = 0.0
    @State private var titleOpacity = 0.0
    @State private var infoTextsOpacity = 0.0
    @State private var navigationButtonOpacity = 0.0
    @State private var nextPage: Bool = false
    
    private var resultText: String {
        switch totalScore {
        case 0...4:
            return "Minimal Anxiety"
        case 5...9:
            return "Mild Anxiety"
        case 10...14:
            return "Moderate Anxiety"
        default:
            return "Severe Anxiety"
        }
    }
    
    private var resultDescription: String {
        switch totalScore {
        case 0...4:
            return "Your anxiety levels are minimal. Keep maintaining a healthy lifestyle."
        case 5...9:
            return "You have mild anxiety. Consider relaxation techniques and monitoring your symptoms."
        case 10...14:
            return "Moderate anxiety detected. It might be helpful to speak with a mental health professional."
        default:
            return "Severe anxiety detected. Seeking professional guidance is strongly recommended."
        }
    }
    
    var body: some View {
        VStack {
            Spacer()
            
            VStack(spacing: 0) {
                VStack(spacing: 0) {
                    
              
                    Text("🧠 Anxiety Test Results")
                        .font(.system(size: 50, weight: .bold, design: .default))
                        .foregroundColor(.white)
                        .padding(.top, 5)
                        .opacity(titleOpacity)
                        .basicEaseIn(delayCount: 0) {
                            titleOpacity = 1.0
                        }
                    
                 
                    VStack(spacing: 10) {
                        Text("Overall Result")
                            .font(.system(size: 30, weight: .semibold, design: .default))
                            .foregroundColor(.white)
                            .padding(.top, 5)
                        Text(resultText)
                            .font(.system(size: 40, weight: .semibold, design: .default))
                            .foregroundColor(.orange)
                            .padding(.top, 5)
                        Text(resultDescription)
                            .font(.system(size: 18, weight: .regular, design: .default))
                            .foregroundColor(.white)
                            .multilineTextAlignment(.center)
                            .padding(.horizontal, 50)
                    }
                    .padding(70)
                    .opacity(infoTextsOpacity)
                    .basicEaseIn(delayCount: 0.2) {
                        infoTextsOpacity = 1.0
                    }
                }
            }
            .background(RoundedRectangle(cornerRadius: 47, style: .continuous)
                            .fill(Color(.systemGray5))
                            .frame(width: 900, height: 400)
                            .clipped(), alignment: .center)
            .frame(width: 900, height: 400, alignment: .center)
            .clipped()
            .cornerRadius(47)
            .opacity(backgroundOpacity)
            .basicEaseIn(delayCount: 0) {
                backgroundOpacity = 1.0
            }
            
            Spacer()
            
           
            HStack(alignment: .bottom, spacing: 0) {
                Spacer()
                Button("Retake Test") {
                    withAnimation {
                        nextPage = true
                    }
                }
                .buttonStyle(NavigationButtonStyle(color: Color(.systemGray5)))
            }
            .padding(.leading, 20)
            .padding(.bottom, 20)
            .opacity(navigationButtonOpacity)
            .basicEaseIn(delayCount: 1) {
                navigationButtonOpacity = 1.0
            }
        }
        .navigationStack()
        .overlay(nextPage ? SeeYouSoonScene() : nil)
    }
}

struct AnxietyResultScene_Previews: PreviewProvider {
    static var previews: some View {
        AnxietyResultScene(totalScore: 10) 
    }
}

