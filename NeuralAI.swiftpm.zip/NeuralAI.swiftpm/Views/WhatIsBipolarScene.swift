import SwiftUI


struct WhatIsBipolarScene: View {

    
  
    @State var nextPage: Bool = false
    @State var backgroundOpacity = 0.0
    @State var navigationButtonOpacity = 0.0
    

    var body: some View {
        VStack {
            Spacer()
            HStack(spacing: 98) {
                
                InfoTextView(subtitle: "What is", subtitleColor: .indigo, title: "Bipolar Disorder?", titleSize: 50, bodyIsOn: true, bodyText: "Bipolar disorder is characterized by extreme mood swings that include emotional highs (mania or hypomania) and lows (depression). These shifts can affect energy levels, judgment, and daily activities.", bodyTextColor: .white, bodyTextSize: 20, bodyPaddingTop: 30, bodyWidth: 500)
                .offset(x: -30, y: 0)
                
                VStack(alignment: .trailing) {
                    Image(systemName: "arrow.triangle.2.circlepath")
                        .font(.system(size: 120, weight: .bold, design: .default))
                }
                .background(RoundedRectangle(cornerRadius: 47, style: .continuous)
                    .fill(Color.indigo)
                    .frame(width: 300, height: 550, alignment: .trailing)
                    .clipped(), alignment: .center)
            }
            .background(RoundedRectangle(cornerRadius: 47, style: .continuous)
                .fill(Color(.systemGray5))
                .frame(width: 900, height: 550)
                .clipped(), alignment: .center)
            .opacity(backgroundOpacity)
            .basicEaseIn(delayCount: 0) {
                backgroundOpacity = 1.0
            }
            
            Spacer()
            
            HStack(alignment: .bottom, spacing: 0) {
                Spacer()
                Button("Next") {
                    withAnimation {
                        nextPage = true
                    }
                }
                .buttonStyle(NavigationButtonStyle(color: .indigo))
            }
            .padding(.leading, 20)
            .padding(.bottom, 20)
            .opacity(navigationButtonOpacity)
            .basicEaseIn(delayCount: 0.6) {
                navigationButtonOpacity = 1.0
            }
        }
        .navigationStack()
        .overlay(nextPage ? WhatIsBipolarAIScene() : nil)
    }
}

