import SwiftUI

struct WhatIsDepressionScene: View {
    
    

    @State var nextPage: Bool = false
    
    @State var backgroundOpacity = 0.0
    @State var navigationButtonOpacity = 0.0
    

    var body: some View {
        VStack {
            Spacer()
            HStack(spacing: 98) {
         
                InfoTextView(subtitle: "What is", subtitleColor: .blue, title: "Depression?", titleSize: 50, bodyIsOn: true, bodyText: "Depression is a common and serious medical illness that negatively affects how you feel, the way you think, and how you act. It causes feelings of sadness and a loss of interest in activities once enjoyed. It can lead to emotional and physical problems and can decrease a person's ability to function at work and at home.", bodyTextColor: .white, bodyTextSize: 20, bodyPaddingTop: 30, bodyWidth: 500)
                .offset(x: -30, y: 0)
            
                
                VStack(alignment: .trailing) {
                    Image(systemName: "brain.head.profile")
                        .font(.system(size: 120, weight: .bold, design: .default))
                }
                .background(RoundedRectangle(cornerRadius: 47, style: .continuous)
                    .fill(Color.blue)
                    .frame(width: 300, height: 550, alignment: .trailing)
                    .clipped(), alignment: .center)
            }
            .background(RoundedRectangle(cornerRadius: 47, style: .continuous)
                .fill(Color(.systemGray5))
                .frame(width: 900, height: 550)
                .clipped(), alignment: .center)
            .opacity(backgroundOpacity)
            .basicEaseIn(delayCount: 0) {
                backgroundOpacity = 1.0
            }
        
            Spacer()
            
 
            HStack(alignment: .bottom, spacing: 0) {
                Spacer()
                Button("Next") {
                    withAnimation {
                        nextPage = true
                    }
                }
                .buttonStyle(NavigationButtonStyle(color: (.blue)))
            }
            .padding(.leading, 20)
            .padding(.bottom, 20)
            .opacity(navigationButtonOpacity)
            .basicEaseIn(delayCount: 0.6) {
                navigationButtonOpacity = 1.0
            }
        }
        .navigationStack()
        .overlay(nextPage ? WhatIsDepressionAIScene() : nil)
    }
}
