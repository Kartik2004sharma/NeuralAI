import SwiftUI

struct DiseaseAI: View {
    var body: some View {
        NavigationView {
            VStack {
                Spacer()
                
                VStack(alignment: .center, spacing: 20) {
                    InfoTextView(
                        subtitle: "NeuroAI",
                        subtitleColor: Color.blue,
                        title: "Welcome",
                        titleSize: 50,
                        bodyIsOn: true,
                        bodyText: "NeuroAI provides information about Alzheimer's and Parkinson's diseases, shows how machine learning assists in diagnosis, and offers AI-powered tests.",
                        bodyTextColor: Color.secondary,
                        bodyTextSize: 20,
                        bodyPaddingTop: 20,
                        bodyWidth: 800
                    )
                    
                    HStack(spacing: 25) {
                        // Alzheimer's Card
                        NavigationLink(destination: Alzheimer()) {
                            CardView(
                                cardSymbolIsOn: true,
                                cardSymbolName: "brain.head.profile",
                                cardSymbolSize: 70,
                                cardSymbolColor: .white,
                                cardSymbolWidth: 250,
                                cardSymbolHeight: 166,
                                cardSubtitleIsOn: true,
                                cardSubtitle: "What is",
                                cardSubtitleSize: 15,
                                cardSubtitleColor: .white,
                                cardTitle: "Alzheimer's",
                                cardTitleSize: 26,
                                cardTitleColor: .white,
                                paddingTop: 0,
                                animationDuration: 0.6,
                                width: 260,
                                height: 260,
                                cornerRadius: 40,
                                backgroundColor: .purple
                            )
                        }
                        
                        NavigationLink(destination: WelcomeParkinson()) {
                            CardView(
                                cardSymbolIsOn: true,
                                cardSymbolName: "brain",
                                cardSymbolSize: 70,
                                cardSymbolColor: .white,
                                cardSymbolWidth: 250,
                                cardSymbolHeight: 166,
                                cardSubtitleIsOn: true,
                                cardSubtitle: "What is",
                                cardSubtitleSize: 15,
                                cardSubtitleColor: .white,
                                cardTitle: "Parkinson's",
                                cardTitleSize: 26,
                                cardTitleColor: .white,
                                paddingTop: 0,
                                animationDuration: 0.7,
                                width: 260,
                                height: 260,
                                cornerRadius: 40,
                                backgroundColor: .blue
                            )
                        }
                        
                       
                        NavigationLink(destination: MentalHealthView()) {
                            CardView(
                                cardSymbolIsOn: true,
                                cardSymbolName: "heart.text.square",
                                cardSymbolSize: 70,
                                cardSymbolColor: .white,
                                cardSymbolWidth: 250,
                                cardSymbolHeight: 166,
                                cardSubtitleIsOn: true,
                                cardSubtitle: "Explore",
                                cardSubtitleSize: 15,
                                cardSubtitleColor: .white,
                                cardTitle: "Mental Health",
                                cardTitleSize: 26,
                                cardTitleColor: .white,
                                paddingTop: 0,
                                animationDuration: 0.8,
                                width: 260,
                                height: 260,
                                cornerRadius: 40,
                                backgroundColor: .green
                            )
                        }
                    }
                    .padding(.top, 50)
                }
                Spacer()
            }
            .navigationBarHidden(true)
        }
        .navigationViewStyle(StackNavigationViewStyle())
    }
}
