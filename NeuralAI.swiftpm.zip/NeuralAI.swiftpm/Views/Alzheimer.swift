import SwiftUI
import AVKit

struct Alzheimer: View {

    
    @State var nextPage: Bool = false
    @State var audioPermissionAlert = true
    @State var videoPermissionAlert = true
    @State var navigationButtonOpacity = 0.0
    

    var body: some View {
        VStack {
            Spacer()
            
            VStack(alignment: .leading, spacing: 0) {
                

                InfoTextView(
                    subtitle: "NeuroAI",
                    subtitleColor: Color.purple,
                    title: "Welcome",
                    titleSize: 50,
                    bodyIsOn: true,
                    bodyText: "NeuroAI provides insights into Alzheimer's disease, explains how AI can assist in diagnosis, and includes a demo Alzheimer's test.",
                    bodyTextColor: Color.secondary,
                    bodyTextSize: 20,
                    bodyPaddingTop: 20,
                    bodyWidth: 800
                )

                HStack(spacing: 25) {
                    
          
                    CardView(
                        cardSymbolIsOn: true,
                        cardSymbolName: "brain.head.profile",
                        cardSymbolSize: 70,
                        cardSymbolColor: .white,
                        cardSymbolWidth: 250,
                        cardSymbolHeight: 166,
                        cardSubtitleIsOn: true,
                        cardSubtitle: "What is",
                        cardSubtitleSize: 15,
                        cardSubtitleColor: .white,
                        cardTitle: "Alzheimer's",
                        cardTitleSize: 26,
                        cardTitleColor: .white,
                        paddingTop: 0,
                        animationDuration: 0.6,
                        width: 250,
                        height: 250,
                        cornerRadius: 40,
                        backgroundColor: .purple
                    )
                    
    
                    CardView(
                        cardSymbolIsOn: true,
                        cardSymbolName: "waveform.path.ecg",
                        cardSymbolSize: 70,
                        cardSymbolColor: .white,
                        cardSymbolWidth: 250,
                        cardSymbolHeight: 166,
                        cardSubtitleIsOn: true,
                        cardSubtitle: "What is",
                        cardSubtitleSize: 15,
                        cardSubtitleColor: .white,
                        cardTitle: "NeuroAI",
                        cardTitleSize: 26,
                        cardTitleColor: .white,
                        paddingTop: 0,
                        animationDuration: 0.7,
                        width: 250,
                        height: 250,
                        cornerRadius: 40,
                        backgroundColor: .blue
                    )
                    
        
                    CardView(
                        cardSymbolIsOn: true,
                        cardSymbolName: "stethoscope",
                        cardSymbolSize: 70,
                        cardSymbolColor: .white,
                        cardSymbolWidth: 250,
                        cardSymbolHeight: 166,
                        cardSubtitleIsOn: false,
                        cardSubtitle: "",
                        cardSubtitleSize: 0,
                        cardSubtitleColor: .white,
                        cardTitle: "AI Diagnosis",
                        cardTitleSize: 26,
                        cardTitleColor: .white,
                        paddingTop: 0,
                        animationDuration: 0.8,
                        width: 250,
                        height: 250,
                        cornerRadius: 40,
                        backgroundColor: .indigo
                    )
                }
                .padding(.top, 60)
            }
            
            Spacer()
            

            HStack {
                Spacer()
                Button("Get Started") {
                    withAnimation {
                        nextPage = true
                    }
                }
                .buttonStyle(NavigationButtonStyle(color: .purple))
            }
            .padding(.leading, 20)
            .padding(.bottom, 20)
            .opacity(navigationButtonOpacity)
            .basicEaseIn(delayCount: 1) {
                navigationButtonOpacity = 1.0
            }
        }
        .navigationStack()
        .overlay(nextPage ? WhatIsAlzheimerScene() : nil)
        .onAppear {
            AVCaptureDevice.requestAccess(for: .audio) { isGranted in
                if !isGranted { audioPermissionAlert = false }
            }
            
            AVCaptureDevice.requestAccess(for: .video) { isGranted in
                if !isGranted { videoPermissionAlert = false }
            }
        }
    }
}
