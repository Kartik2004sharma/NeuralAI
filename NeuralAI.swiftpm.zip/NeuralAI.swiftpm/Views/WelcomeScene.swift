import SwiftUI
import AVKit

struct WelcomeScene: View {
    

    
    @State var nextPage: Bool = false
    
    @State var audioPermissionAlert = true
    @State var videoPermissionAlert = true
    

    @State var navigationButtonOpacity = 0.0
    
 
    var body: some View {
        VStack {
            
            Spacer()
            
            VStack(alignment: .leading, spacing: 0) {
                
        
                InfoTextView(subtitle: "NeuroAI", subtitleColor: Color.blue, title: "Welcome", titleSize: 50, bodyIsOn: true, bodyText: "NeuroAI is designed to provide insights into neurological disorders, demonstrate how AI can assist in early diagnosis, and offer a hands-on diagnostic test.", bodyTextColor: Color.secondary, bodyTextSize: 20, bodyPaddingTop: 20, bodyWidth: 800)
                
        
                HStack(spacing: 25) {
                    
             
                    CardView(cardSymbolIsOn: true, cardSymbolName: "brain", cardSymbolSize: 70, cardSymbolColor: .white, cardSymbolWidth: 250, cardSymbolHeight: 166, cardSubtitleIsOn: true, cardSubtitle: "Discover", cardSubtitleSize: 15, cardSubtitleColor: .white, cardTitle: "NeuroAI", cardTitleSize: 26, cardTitleColor: .white, paddingTop: 0, animationDuration: 0.6, width: 250, height: 250, cornerRadius: 40, backgroundColor: .blue)
                    
                    // "Understanding Neurological Disorders" Card
                    CardView(cardSymbolIsOn: true, cardSymbolName: "waveform.path.ecg", cardSymbolSize: 70, cardSymbolColor: .white, cardSymbolWidth: 250, cardSymbolHeight: 166, cardSubtitleIsOn: true, cardSubtitle: "Learn about", cardSubtitleSize: 15, cardSubtitleColor: .white, cardTitle: "Neuro Disorders", cardTitleSize: 26, cardTitleColor: .white, paddingTop: 0, animationDuration: 0.7, width: 250, height: 250, cornerRadius: 40, backgroundColor: .indigo)
                    
                    // "AI-Powered Diagnosis" Card
                    CardView(cardSymbolIsOn: true, cardSymbolName: "stethoscope", cardSymbolSize: 70, cardSymbolColor: .white, cardSymbolWidth: 250, cardSymbolHeight: 166, cardSubtitleIsOn: false, cardSubtitle: "", cardSubtitleSize: 0, cardSubtitleColor: .white, cardTitle: "AI Diagnosis", cardTitleSize: 26, cardTitleColor: .white, paddingTop: 0, animationDuration: 0.8, width: 250, height: 250, cornerRadius: 40, backgroundColor: .purple)
                }
                .background(Group {
                    EmptyView()
                }, alignment: .center)
                .padding(.top, 60)
            }
            
            Spacer()
            
            // Navigation Button
            HStack(alignment: .bottom, spacing: 0) {
                Spacer()
                Button("Get Started") {
                    withAnimation {
                        nextPage = true
                    }
                }
                .buttonStyle(NavigationButtonStyle(color: .blue))
            }
            .padding(.leading, 20)
            .padding(.bottom, 20)
            .opacity(navigationButtonOpacity)
            .basicEaseIn(delayCount: 1, {
                navigationButtonOpacity = 1.0
            })
        }
        .navigationStack()
        .overlay(nextPage ? DiseaseAI() : nil)
        .onAppear {
            AVCaptureDevice.requestAccess(for: .audio) { isGranted in
                if isGranted == false {
                    audioPermissionAlert = false
                }
            }
            
            AVCaptureDevice.requestAccess(for: .video) { isGranted in
                if isGranted == false {
                    videoPermissionAlert = false
                }
            }
        }
    }
}

