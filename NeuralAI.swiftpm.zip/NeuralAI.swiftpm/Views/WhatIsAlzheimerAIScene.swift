import SwiftUI

struct WhatIsAlzheimerAIScene: View {

    @State var nextPage: Bool = false
    

    @State var backgroundOpacity = 0.0
    @State var navigationButtonOpacity = 0.0
    

    
    var body: some View {
        VStack {
            Spacer()
            HStack(spacing: 15) {
         
                InfoTextView(subtitle: "What is", subtitleColor: .purple, title: "AlzheimerAI", titleSize: 50, bodyIsOn: true, bodyText: "AlzheimerAI is a machine-learning-based app that can diagnose Alzheimer's disease through three different tests. The first test analyzes handwriting patterns to detect cognitive impairment. The second test is a speech analysis to identify language-related symptoms. The third test evaluates memory recall to detect early signs of Alzheimer's.", bodyTextColor: .white, bodyTextSize: 20, bodyPaddingTop: 30, bodyWidth: 500)
                .background(RoundedRectangle(cornerRadius: 47, style: .continuous)
                                .fill(Color(.systemGray5))
                                .frame(width: 585, height: 550)
                                .clipped(), alignment: .center)
                
          
                VStack(spacing: 58) {
                    
  
                    CardView(cardSymbolIsOn: true, cardSymbolName: "pencil.and.outline", cardSymbolSize: 40, cardSymbolColor: .white, cardSymbolWidth: 173, cardSymbolHeight: 100, cardSubtitleIsOn: true, cardSubtitle: "Step 1", cardSubtitleSize: 10, cardSubtitleColor: .orange, cardTitle: "Handwriting Analysis", cardTitleSize: 13, cardTitleColor: .white, paddingTop: 0, animationDuration: 0.6, width: 173, height: 173, cornerRadius: 47, backgroundColor: Color(.systemGray5))
         
                    CardView(cardSymbolIsOn: true, cardSymbolName: "waveform", cardSymbolSize: 40, cardSymbolColor: .white, cardSymbolWidth: 173, cardSymbolHeight: 100, cardSubtitleIsOn: true, cardSubtitle: "Step 2", cardSubtitleSize: 10, cardSubtitleColor: .orange, cardTitle: "Speech Analysis", cardTitleSize: 13, cardTitleColor: .white, paddingTop: 0, animationDuration: 0.7, width: 173, height: 173, cornerRadius: 47, backgroundColor: Color(.systemGray5))
                    
                    // Memory Recall Test Card
                    CardView(cardSymbolIsOn: true, cardSymbolName: "brain.head.profile", cardSymbolSize: 40, cardSymbolColor: .white, cardSymbolWidth: 173, cardSymbolHeight: 100, cardSubtitleIsOn: true, cardSubtitle: "Step 3", cardSubtitleSize: 10, cardSubtitleColor: .orange, cardTitle: "Memory Recall Test", cardTitleSize: 13, cardTitleColor: .white, paddingTop: 0, animationDuration: 0.8, width: 173, height: 173, cornerRadius: 47, backgroundColor: Color(.systemGray5))
                }
                .padding(.leading, 42)
            }
            .background(Group {
                EmptyView()
            }, alignment: .center)
            .frame(width: 900, height: 550, alignment: .center)
            .clipped()
            .cornerRadius(47)
            .opacity(backgroundOpacity)
            .basicEaseIn(delayCount: 0) {
                backgroundOpacity = 1.0
            }
            
            Spacer()
            
         
            HStack(alignment: .bottom, spacing: 0) {
                Spacer()
                Button("Let's Start") {
                    withAnimation {
                        nextPage = true
                    }
                }
                .buttonStyle(NavigationButtonStyle(color: .purple))
            }
            .padding(.leading, 20)
            .padding(.bottom, 20)
            .opacity(navigationButtonOpacity)
            .basicEaseIn(delayCount: 1) {
                navigationButtonOpacity = 1.0
            }
            
        }
        .navigationStack()
        .overlay(nextPage ? RequiredQuestion() : nil)
    }
}

