import UIKit
import CoreML
import Vision

class ImageClassificationProvider {
    
    // MARK: Functions
    
    // Processing Image Output
    func predictionResult(image: UIImage) {
        
        let newSize = CGSize(width: 299, height: 299)
        guard let resizedImage = image.resizeImageTo(size: newSize) else {
            fatalError("⚠️ The image could not be found or resized.")
        }
        
        guard let convertedImage = resizedImage.convertToBuffer() else {
            fatalError("⚠️ The image could not be converted to CVPixelBugger")
        }
        
        guard let mlModel = try? PAIHandwritingML(configuration: MLModelConfiguration()) else { return }
        
        // Prediction Output
        guard let prediction = try? mlModel.prediction(image: convertedImage) else {
            fatalError("⚠️ The model could not return a prediction")
        }
        
        // Getting the ParkinsonHand classification.
        guard let probabilities = prediction.classLabelProbs["ParkinsonHandwriting"] else { return }
        
        
        // Getting the result as a percentage.
        let confidence =  probabilities * 100.0
        
        // Informing the OverallScoreCalculator to update the handwritingTestResult variable.
        OverallScoreCalculator.shared.handwritingTestResult = Int(confidence)
    }
}



