import SwiftUI


struct PAIProgressView: View {
    
    var body: some View {
        ZStack {
            
      
            Rectangle()
                .frame(maxWidth: .infinity, maxHeight: .infinity)
                .foregroundColor(.black)
                .opacity(0.7)
                .zIndex(1.0)
            
            VStack {
                
             
                Text("Analyzing...")
                    .font(.system(size: 17, weight: .bold, design: .default))
                
                ProgressView()
            }
            .background(RoundedRectangle(cornerRadius: 25, style: .continuous)
                            .fill(Color(.systemGray4))
                            .frame(width: 160, height: 90)
                            .clipped(), alignment: .center)
            .zIndex(2.0)
        }
    }
    
}
