// OverallScore.swift
import SwiftUI

final class OverallScore: ObservableObject {
    // MARK: - Score Types
    enum CognitiveLevel: String {
        case normal = "Normal Cognitive Function"
        case mildImpairment = "Mild Cognitive Impairment"
        case moderateImpairment = "Moderate Cognitive Impairment"
        case severeImpairment = "Severe Cognitive Impairment"
    }
    
    // MARK: - Published Properties
    @Published private(set) var lastCalculatedScore: Int = 0
    @Published private(set) var cognitiveLevel: CognitiveLevel = .normal
    
    // MARK: - Constants
    private let weights = (
        memory: 40,
        speech: 30,
        cognitive: 30
    )
    
    // MARK: - Singleton Instance
    static let shared = OverallScore()
    
    // MARK: - Initialization
    private init() {}
    
    // MARK: - Public Methods
    func calculate(memoryScore: Int, speechScore: Int, cognitiveScore: Int) -> Int {
        // Ensure scores are within valid range
        let validMemoryScore = max(0, min(100, memoryScore))
        let validSpeechScore = max(0, min(100, speechScore))
        let validCognitiveScore = max(0, min(100, cognitiveScore))
        
        // Calculate weighted contributions
        let memoryContribution = (validMemoryScore * weights.memory) / 100
        let speechContribution = (validSpeechScore * weights.speech) / 100
        let cognitiveContribution = (validCognitiveScore * weights.cognitive) / 100
        
        // Calculate total score
        let totalScore = memoryContribution + speechContribution + cognitiveContribution
        
        // Update published properties
        lastCalculatedScore = totalScore
        cognitiveLevel = determineCognitiveLevel(totalScore: totalScore)
        
        return totalScore
    }
    
    // MARK: - Private Methods
    private func determineCognitiveLevel(totalScore: Int) -> CognitiveLevel {
        switch totalScore {
        case 80...100:
            return .normal
        case 60..<80:
            return .mildImpairment
        case 40..<60:
            return .moderateImpairment
        default:
            return .severeImpairment
        }
    }
    
    // MARK: - Analysis Methods
    func getAnalysis() -> String {
        """
        Overall Score: \(lastCalculatedScore)/100
        Cognitive Level: \(cognitiveLevel.rawValue)
        
        Score Breakdown:
        - Memory weight: \(weights.memory)%
        - Speech weight: \(weights.speech)%
        - Cognitive weight: \(weights.cognitive)%
        """
    }
    
    func getRecommendations() -> [String] {
        switch cognitiveLevel {
        case .normal:
            return [
                "Continue regular cognitive exercises",
                "Maintain healthy lifestyle habits",
                "Schedule annual cognitive screenings",
                "Stay socially active"
            ]
        case .mildImpairment:
            return [
                "Consult with a healthcare professional",
                "Increase cognitive stimulation activities",
                "Start memory training exercises",
                "Consider lifestyle modifications"
            ]
        case .moderateImpairment:
            return [
                "Seek neurological evaluation",
                "Implement daily cognitive exercises",
                "Consider medication evaluation",
                "Establish support systems"
            ]
        case .severeImpairment:
            return [
                "Immediate medical consultation required",
                "Establish care plan with specialists",
                "Consider safety modifications",
                "Set up regular monitoring"
            ]
        }
    }
}
