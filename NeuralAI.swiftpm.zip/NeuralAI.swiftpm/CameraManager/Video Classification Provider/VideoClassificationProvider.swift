import AVFoundation
import Foundation
import Vision
import SwiftUI

final class VideoClassificationProvider: PoseRecognizer {
    
    // MARK: Functions
    
    func recognizeHandPose(from url: URL) {
        grabPoses(from: url) { [self] poses in
            let poses = poses.prefix(predictionWindow).map { x in x }
            
            // Getting the ParkinsonHand classification.
            guard let prediction = makePrediction(posesWindow: poses),
                  let probabilities = prediction.featureValue(for: "labelProbabilities")?.dictionaryValue, let parkinsonHandPrediction = probabilities["ParkinsonHand"]?.floatValue else { return }
            
            // Getting the result as a percentage.
            let confidence =  parkinsonHandPrediction * 100.0
            
            // Informing the OverallScoreCalculator to update the handTremorTestResult variable.
            OverallScoreCalculator.shared.handTremorTestResult = Int(confidence)
        }
    }
    
    func grabPoses(from assetURL: URL, completion: @escaping ([VNHumanHandPoseObservation]) -> Void) {
        var allPoses = [VNHumanHandPoseObservation]()
        _ = AVAsset(url: assetURL)
        let visionRequest = VNDetectHumanHandPoseRequest { vnRequest, error in
            if let error = error {
                fatalError(error.localizedDescription)
            }
            if let poseObservations = vnRequest.results as? [VNHumanHandPoseObservation] {
                allPoses.append(contentsOf: poseObservations)
                if allPoses.count == self.predictionWindow {
                    completion(allPoses)
                }
            }
        }
        do {
            let videoProcessor = VNVideoProcessor(url: assetURL)
            try videoProcessor.addRequest(visionRequest, processingOptions: VNVideoProcessor.RequestProcessingOptions())
            try videoProcessor.analyze(CMTimeRange(start: .zero, duration: CMTime(seconds: 3, preferredTimescale: .min)))
            
        } catch {
            fatalError(error.localizedDescription)
        }
    }
    
}
