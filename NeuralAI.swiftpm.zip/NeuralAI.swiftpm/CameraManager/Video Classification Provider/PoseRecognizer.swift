import AVFoundation
import Foundation
import Vision

class PoseRecognizer {
    
    // MARK: Properties
    
    // Prediction Window parameter for the Model Input
    let predictionWindow = 90
    let model = try? PAIHandTremorML(configuration: MLModelConfiguration())
    
    // MARK: Functions
    
    // Make a model prediction on a window.
    func makePrediction(posesWindow: [VNHumanHandPoseObservation]) -> MLFeatureProvider? {
        // Prepare model input: convert each pose to a multi-array, and concatenate multi-arrays.
        let poseMultiArrays: [MLMultiArray] = posesWindow.map { try! $0.keypointsMultiArray() }
        let modelInput = MLMultiArray(concatenating: poseMultiArrays, axis: 0, dataType: .float)
        var prediction: MLFeatureProvider?
        
        // Perform prediction
        do {
            prediction = try model?.prediction(input: PAIHandTremorMLInput(poses: modelInput))
        } catch {
            fatalError(error.localizedDescription)
        }
        return prediction
    }
    
}
