import SwiftUI

struct CameraView: View {
    
    // MARK: Properties
    
    @EnvironmentObject var cameraModel: CameraViewModel
    
    // MARK: View
    
    var body: some View {
        
        GeometryReader { proxy in
            
            // CameraPreview view which is transformed from UIView.
            CameraPreview(size: proxy.size)
                .environmentObject(cameraModel)
        }
            .frame(width: 500, height: 300, alignment: .center)
            .cornerRadius(40)
            .onAppear(perform: cameraModel.checkPermission)
            .alert(isPresented: $cameraModel.alert) {
                Alert(title: Text("Please Enable cameraModel Access Or Microphone Access!!!"))
            }
            .onReceive(Timer.publish(every: 0.1, on: .main, in: .common).autoconnect()) { _ in
                if cameraModel.recordedDuration <= cameraModel.maxDuration && cameraModel.isRecording{
                    cameraModel.recordedDuration += 0.1
                }
            
                if cameraModel.recordedDuration >= cameraModel.maxDuration && cameraModel.isRecording{
                    
                    // Stopping the Recording
                    cameraModel.stopRecording()
                    cameraModel.isRecording = false
                    cameraModel.recordedDuration = 0
                }
            }
        
    }
    
}
