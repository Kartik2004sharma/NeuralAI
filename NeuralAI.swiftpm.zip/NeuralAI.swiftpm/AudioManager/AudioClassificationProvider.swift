import CoreML
import SoundAnalysis
import AVKit

class AudioClassificationProvider : NSObject, SNResultsObserving {
    
    // MARK: Functions
    
    func request(_ request: SNRequest, didProduce result: SNResult) {
        // Getting the ParkinsonVoice classification.
        guard let result = result as? SNClassificationResult,
              let parkinsonVoicePrediction = result.classification(forIdentifier: "ParkinsonVoice") else { return }
        
        // Getting the result as a percentage.
        let confidence = parkinsonVoicePrediction.confidence * 100.0
        
        // Informing the OverallScoreCalculator to update the speakingTestResult variable.
        OverallScoreCalculator.shared.speakingTestResult = Int(confidence)
    }
    
    func request(_ request: SNRequest, didFailWithError error: Error) {
        print("The the analysis failed: \(error.localizedDescription)")
    }
    
    func requestDidComplete(_ request: SNRequest) {
        print("The request completed successfully!")
    }
    
    public func predictionResult(audioFileUrl: URL) {
        var model: MLModel!  
        
        //Access the bundled CoreML model
        let soundClassifier = try? PAISpeakingML()
        model = soundClassifier?.model      
        
        do {
            // Creating a new audio file analyzer.
            let audioFileAnalyzer = try SNAudioFileAnalyzer(url: audioFileUrl)
            
            // Creating a new observer that will be notified of analysis results.
            let resultsObserver = AudioClassificationProvider()
            
            do {
                // Preparing a new request for the trained model.
                let request = try SNClassifySoundRequest(mlModel: model)
                try audioFileAnalyzer.add(request, withObserver: resultsObserver)
            } catch {
                print(error.localizedDescription)
            }
            audioFileAnalyzer.analyze()
        } catch {
            print(error.localizedDescription)
        }
    }
    
}
